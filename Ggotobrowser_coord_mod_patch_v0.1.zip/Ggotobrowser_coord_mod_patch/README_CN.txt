Ggotobrowser 坐标 MOD 实验补丁（目标：GotoBrowser 3.0 rev9 / 当前 master）
===================================================================

重要说明
--------
这不是已经编译好的 APK。本次运行环境没有 Android SDK/Gradle，也无法从命令行取得 Android/Maven 构建依赖，因此我不能声称 APK 已经编译或真机运行通过。
本包提供的是：可自动应用到官方开源源码的补丁 + 坐标核心代码 + 样例 INI + 逻辑测试 + GitHub Actions 构建模板。

设计原则
--------
1. applicationId 保持 com.antest1.gotobrowser，不改包名。
2. Kcanotify 先收到原始 kcsapi 数据。
3. 只有返回给本地游戏 WebView 的 api_start2 副本会修改 api_mst_shipgraph 坐标。
4. 不改变舰娘属性、战斗数据、装备、资源、请求参数。
5. INI 读取或 JSON 修改发生任何异常时，直接返回官方原始数据（fail-open），优先保证游戏可启动。
6. 有 INI 才启用；没有 INI 时行为与原版一致。

手机 INI 目录
-------------
Android/data/com.antest1.gotobrowser/files/coord_mod/

推荐文件名
----------
优先：<api_filename>.config.ini
兼容：<api_filename>_1.config.ini
兼容：<api_filename>.ini
兜底：<api_id>.config.ini

例：
123456789012.config.ini

内容：
[graph]
boko_n_left=120
boko_n_top=-35
boko_d_left=115
boko_d_top=-30
battle_n_left=80
battle_n_top=-10
battle_d_left=75
battle_d_top=-5

坐标方向
--------
left 增大：向右
left 减小：向左
top 增大：向下
top 减小：向上

如何应用源码补丁
----------------
1. 下载/克隆官方 GotoBrowser 源码。
2. 将整个 Ggotobrowser_coord_mod_patch 文件夹放在任意位置。
3. Windows 命令行执行：
   python apply_patch.py D:\你的路径\GotoBrowser
4. 成功时显示 PATCH OK。
5. 原文件备份在源码根目录：_ggotobrowser_backup
6. 编译源码。显示名称会尝试改成 Ggotobrowser；包名不会改。

首次安装注意
------------
你自己编译的 APK 签名与官方 GotoBrowser 不同，即使包名相同，Android 也不能覆盖官方安装包。
请先备份 GotoBrowser 的缓存/配置，卸载官方版，再安装你自己的 Ggotobrowser。
以后所有 Ggotobrowser 版本都用同一份 keystore，即可覆盖升级。

建议测试顺序（非常重要）
------------------------
A. 空配置安全性测试
1. coord_mod 目录保持为空。
2. 启动 Ggotobrowser，登录舰队 Collection。
3. 确认母港、编成、战斗正常。
4. 确认 Kcanotify 能读取舰队、远征、入渠等数据。
=> 这一关失败，立即停止测试。

B. 单舰母港坐标测试
1. 找一名秘书舰的 api_filename。
2. 建立 <api_filename>.config.ini。
3. 只写：
   [graph]
   boko_n_left=原值+100
   boko_n_top=原值
4. 完全关闭并重新打开游戏页。
5. 秘书舰应明显向右移动约 100 的坐标量。
6. Kcanotify 信息应完全不变。

C. 中破/战斗测试
逐项测试 boko_d、battle_n、battle_d，不要一次改十几个字段，方便定位错误。

D. 故障回退测试
1. 故意把一个坐标写成 abc。
2. 该值应被忽略，游戏不能猫页/崩溃。
3. 删除 INI 后重新打开，显示应恢复官方坐标。

E. Kcanotify 联动验证
1. Ggotobrowser Broadcast Mode 开启。
2. Kcanotify 选择 GotoBrowser/对应被动读取模式。
3. 编成变化、出击、远征等应正常更新。
4. 调整立绘坐标时 Kcanotify 的舰娘 ID、HP、装备等不得变化。

当前已做的本地测试
------------------
- 无 INI 时原始响应保持完全不变。
- api_filename 匹配覆盖。
- api_id 兜底匹配。
- filename 配置优先于 ID 配置。
- 左/上坐标分别覆盖。
- 不存在的 api 字段不会被凭空创建。
- 非法数字忽略。

未能在此环境完成
----------------
- Android Gradle 完整编译。
- APK 签名。
- Android 模拟器/真机启动。
- 实际 DMM/舰队 Collection 登录。

许可
----
GotoBrowser 为 GPL-3.0 开源项目。发布修改版 APK 时，应遵守上游 GPL-3.0 许可并提供对应修改源码/源码获取方式。
