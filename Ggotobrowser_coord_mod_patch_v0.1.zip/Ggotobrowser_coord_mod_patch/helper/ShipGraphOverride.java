package com.antest1.gotobrowser.Helpers;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Local-only shipgraph coordinate override for Ggotobrowser.
 *
 * Reads ShimakazeGo-style *.config.ini files from:
 *   Android/data/com.antest1.gotobrowser/files/coord_mod/
 *
 * It only changes api_mst_shipgraph coordinate arrays in the response copy
 * returned to the local game client. The original response is still passed to
 * Kcanotify by KcsInterface before this method is called.
 */
public final class ShipGraphOverride {
    private final File rootDir;

    public ShipGraphOverride(File rootDir) {
        this.rootDir = rootDir;
    }

    public String apply(String responseRaw) {
        if (responseRaw == null || responseRaw.length() == 0 || rootDir == null) {
            return responseRaw;
        }

        try {
            final boolean hasPrefix = responseRaw.startsWith("svdata=");
            final String jsonText = hasPrefix ? responseRaw.substring(7) : responseRaw;
            JsonObject root = JsonParser.parseString(jsonText).getAsJsonObject();
            if (!root.has("api_data") || !root.get("api_data").isJsonObject()) return responseRaw;

            JsonObject apiData = root.getAsJsonObject("api_data");
            if (!apiData.has("api_mst_shipgraph") || !apiData.get("api_mst_shipgraph").isJsonArray()) {
                return responseRaw;
            }

            boolean changed = false;
            JsonArray graphs = apiData.getAsJsonArray("api_mst_shipgraph");
            for (JsonElement element : graphs) {
                if (!element.isJsonObject()) continue;
                JsonObject graph = element.getAsJsonObject();
                File config = findConfig(graph);
                if (config == null) continue;

                Map<String, Integer> values = readGraphSection(config);
                if (values.isEmpty()) continue;
                if (applyValues(graph, values)) changed = true;
            }

            if (!changed) return responseRaw;
            return (hasPrefix ? "svdata=" : "") + root.toString();
        } catch (Exception ignored) {
            // Fail-open: malformed INI/JSON must never stop the game from loading.
            return responseRaw;
        }
    }

    private File findConfig(JsonObject graph) {
        String filename = getString(graph, "api_filename");
        String id = getString(graph, "api_id");

        String[] candidates = new String[] {
                filename.length() == 0 ? "" : filename + ".config.ini",
                filename.length() == 0 ? "" : filename + "_1.config.ini",
                filename.length() == 0 ? "" : filename + ".ini",
                id.length() == 0 ? "" : id + ".config.ini"
        };

        for (String name : candidates) {
            if (name.length() == 0) continue;
            File file = new File(rootDir, name);
            if (file.isFile()) return file;
        }
        return null;
    }

    private static String getString(JsonObject object, String key) {
        try {
            return object.has(key) ? object.get(key).getAsString() : "";
        } catch (Exception ignored) {
            return "";
        }
    }

    private static Map<String, Integer> readGraphSection(File file) {
        Map<String, Integer> result = new LinkedHashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            boolean inGraph = false;
            String line;
            boolean firstLine = true;
            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    line = line.replace("\uFEFF", "");
                    firstLine = false;
                }
                line = line.trim();
                if (line.length() == 0 || line.startsWith(";") || line.startsWith("#")) continue;

                if (line.startsWith("[") && line.endsWith("]")) {
                    inGraph = "graph".equalsIgnoreCase(line.substring(1, line.length() - 1).trim());
                    continue;
                }
                if (!inGraph) continue;

                int eq = line.indexOf('=');
                if (eq <= 0) continue;
                String key = line.substring(0, eq).trim().toLowerCase(Locale.US);
                String raw = line.substring(eq + 1).trim();
                int comment = raw.indexOf(';');
                if (comment >= 0) raw = raw.substring(0, comment).trim();
                comment = raw.indexOf('#');
                if (comment >= 0) raw = raw.substring(0, comment).trim();

                try {
                    result.put(key, Integer.parseInt(raw));
                } catch (NumberFormatException ignored) {
                    // Ignore one bad value instead of disabling the whole MOD.
                }
            }
        } catch (Exception ignored) {
            return new LinkedHashMap<>();
        }
        return result;
    }

    private static boolean applyValues(JsonObject graph, Map<String, Integer> values) {
        boolean changed = false;
        Map<String, Integer> left = new LinkedHashMap<>();
        Map<String, Integer> top = new LinkedHashMap<>();

        for (Map.Entry<String, Integer> entry : values.entrySet()) {
            String key = entry.getKey();
            if (key.endsWith("_left")) {
                left.put(key.substring(0, key.length() - 5), entry.getValue());
            } else if (key.endsWith("_top")) {
                top.put(key.substring(0, key.length() - 4), entry.getValue());
            }
        }

        Map<String, Integer> bases = new LinkedHashMap<>();
        bases.putAll(left);
        for (Map.Entry<String, Integer> entry : top.entrySet()) {
            if (!bases.containsKey(entry.getKey())) bases.put(entry.getKey(), entry.getValue());
        }

        for (String base : bases.keySet()) {
            String apiKey = base.startsWith("api_") ? base : "api_" + base;
            if (!graph.has(apiKey) || !graph.get(apiKey).isJsonArray()) continue;
            JsonArray arr = graph.getAsJsonArray(apiKey);
            if (arr.size() < 2) continue;

            if (left.containsKey(base)) {
                arr.set(0, new JsonPrimitive(left.get(base)));
                changed = true;
            }
            if (top.containsKey(base)) {
                arr.set(1, new JsonPrimitive(top.get(base)));
                changed = true;
            }
        }
        return changed;
    }
}
