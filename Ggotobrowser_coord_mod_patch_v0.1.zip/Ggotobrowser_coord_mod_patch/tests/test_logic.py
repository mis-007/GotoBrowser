import configparser, json, tempfile
from pathlib import Path

# Python reference model for the exact intended Java behavior.
def apply(response_raw: str, folder: Path):
    prefix = response_raw.startswith('svdata=')
    obj = json.loads(response_raw[7:] if prefix else response_raw)
    graphs = obj.get('api_data', {}).get('api_mst_shipgraph', [])
    changed = False
    for g in graphs:
        fn, sid = str(g.get('api_filename','')), str(g.get('api_id',''))
        candidates = [f'{fn}.config.ini', f'{fn}_1.config.ini', f'{fn}.ini', f'{sid}.config.ini']
        cfg = next((folder/x for x in candidates if x and (folder/x).is_file()), None)
        if not cfg: continue
        cp = configparser.ConfigParser()
        cp.read(cfg, encoding='utf-8-sig')
        if 'graph' not in cp: continue
        for k,v in cp['graph'].items():
            try: iv = int(v.split(';')[0].split('#')[0].strip())
            except: continue
            if k.endswith('_left'): base, idx = k[:-5], 0
            elif k.endswith('_top'): base, idx = k[:-4], 1
            else: continue
            api = base if base.startswith('api_') else 'api_'+base
            if api in g and isinstance(g[api], list) and len(g[api]) >= 2:
                g[api][idx] = iv; changed = True
    if not changed: return response_raw
    return ('svdata=' if prefix else '') + json.dumps(obj, separators=(',',':'))

sample = {'api_data': {'api_mst_shipgraph': [
    {'api_id':50,'api_filename':'123456789012','api_boko_n':[1,2],'api_battle_d':[3,4]},
    {'api_id':51,'api_filename':'999999999999','api_boko_n':[5,6]}
]}}
raw='svdata='+json.dumps(sample,separators=(',',':'))

with tempfile.TemporaryDirectory() as td:
    p=Path(td)
    assert apply(raw,p) == raw, 'no-config must be byte-identical'
    (p/'50.config.ini').write_text('[graph]\nboko_n_left=70\nboko_n_top=80\n',encoding='utf-8')
    out=apply(raw,p); o=json.loads(out[7:])
    assert o['api_data']['api_mst_shipgraph'][0]['api_boko_n']==[70,80], 'ID fallback failed'
    (p/'123456789012.config.ini').write_text('[graph]\nboko_n_left=120\nboko_n_top=-35\nbattle_d_left=75\nbattle_d_top=-5\nunknown_left=9\n',encoding='utf-8')
    out=apply(raw,p); o=json.loads(out[7:])
    g=o['api_data']['api_mst_shipgraph'][0]
    assert g['api_boko_n']==[120,-35], 'filename override failed'
    assert g['api_battle_d']==[75,-5], 'second coordinate field failed'
    assert 'api_unknown' not in g, 'must not create unknown graph fields'
    print('ALL TESTS PASSED')
