from pathlib import Path
import re, shutil, sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
KCS = ROOT / 'app/src/main/java/com/antest1/gotobrowser/Browser/KcsInterface.java'
HELPERS = ROOT / 'app/src/main/java/com/antest1/gotobrowser/Helpers'
STRINGS = ROOT / 'app/src/main/res/values/strings.xml'
HERE = Path(__file__).resolve().parent

if not KCS.exists():
    raise SystemExit(f'ERROR: GotoBrowser source root not found: {ROOT}\nRun: python apply_patch.py <GotoBrowser-source-folder>')

backup = ROOT / '_ggotobrowser_backup'
backup.mkdir(exist_ok=True)
shutil.copy2(KCS, backup / 'KcsInterface.java')
if STRINGS.exists(): shutil.copy2(STRINGS, backup / 'strings.xml')

HELPERS.mkdir(parents=True, exist_ok=True)
shutil.copy2(HERE / 'helper/ShipGraphOverride.java', HELPERS / 'ShipGraphOverride.java')

text = KCS.read_text(encoding='utf-8')

# Imports
if 'import com.antest1.gotobrowser.Helpers.ShipGraphOverride;' not in text:
    anchor = 'import com.antest1.gotobrowser.Helpers.KcUtils;'
    if anchor not in text: raise SystemExit('ERROR: KcsInterface import anchor changed upstream.')
    text = text.replace(anchor, anchor + '\nimport com.antest1.gotobrowser.Helpers.ShipGraphOverride;')
if 'import java.io.File;' not in text:
    anchor = 'import java.util.Locale;'
    if anchor not in text: raise SystemExit('ERROR: KcsInterface java import anchor changed upstream.')
    text = text.replace(anchor, 'import java.io.File;\n' + anchor)

# Axios interception: Kcanotify gets ORIGINAL data first, game gets local coordinate override second.
pattern = re.compile(r'public static final String AXIOS_INTERCEPT_SCRIPT\s*=\s*".*?";', re.S)
replacement = ('public static final String AXIOS_INTERCEPT_SCRIPT = '
    '"axios.interceptors.response.use(function(response){if(response.config.url.includes(\\\"kcsapi\\\")){'
    'var url=response.config.url;var request=response.config.data;var host=window.location.hostname;var data=response.data;'
    'GotoBrowser.kcs_xhr_intercept(host,url,request,data);'
    'if(url.includes(\\\"api_start2\\\")){try{response.data=GotoBrowser.kcs_shipgraph_override(url,data);}catch(e){console.error(\\\"Ggotobrowser coord mod\\\",e);}}'
    '}return response;},function(error){return Promise.reject(error);});";')
text2, count = pattern.subn(replacement, text, count=1)
if count != 1: raise SystemExit('ERROR: AXIOS_INTERCEPT_SCRIPT not found or changed upstream.')
text = text2

# Field
field_anchor = 'private final BrowserActivity activity;'
if 'private final ShipGraphOverride shipGraphOverride;' not in text:
    if field_anchor not in text: raise SystemExit('ERROR: activity field anchor changed upstream.')
    text = text.replace(field_anchor, field_anchor + '\n    private final ShipGraphOverride shipGraphOverride;', 1)

# Constructor init
ctor_anchor = 'activity = ac;'
if 'new ShipGraphOverride' not in text:
    if ctor_anchor not in text: raise SystemExit('ERROR: constructor anchor changed upstream.')
    init = ('activity = ac;\n'
            '        File externalFiles = activity.getExternalFilesDir(null);\n'
            '        shipGraphOverride = new ShipGraphOverride(externalFiles == null ? null : new File(externalFiles, "coord_mod"));')
    text = text.replace(ctor_anchor, init, 1)

# JS interface
if 'public String kcs_shipgraph_override' not in text:
    anchor = '    @JavascriptInterface\n    public void kcs_process_canvas_dataurl'
    method = '''    @JavascriptInterface
    public String kcs_shipgraph_override(String url, String responseRaw) {
        if (url == null || responseRaw == null || !url.contains("api_start2")) return responseRaw;
        return shipGraphOverride.apply(responseRaw);
    }

'''
    if anchor not in text:
        # tolerate blank-line formatting from GitHub checkout
        idx = text.find('public void kcs_process_canvas_dataurl')
        if idx < 0: raise SystemExit('ERROR: canvas JS-interface anchor changed upstream.')
        start = text.rfind('@JavascriptInterface', 0, idx)
        if start < 0: raise SystemExit('ERROR: JavascriptInterface anchor changed upstream.')
        text = text[:start] + method + text[start:]
    else:
        text = text.replace(anchor, method + anchor, 1)

KCS.write_text(text, encoding='utf-8')

# App display name only. Keep applicationId/package untouched for Kcanotify compatibility.
if STRINGS.exists():
    s = STRINGS.read_text(encoding='utf-8')
    s2, n = re.subn(r'(<string\s+name="app_name"[^>]*>)(.*?)(</string>)', r'\1Ggotobrowser\3', s, count=1, flags=re.S)
    if n:
        STRINGS.write_text(s2, encoding='utf-8')
    else:
        print('WARN: app_name string not found; app will keep the original display name.')

print('PATCH OK')
print('Helper:', HELPERS / 'ShipGraphOverride.java')
print('Config folder on phone: Android/data/com.antest1.gotobrowser/files/coord_mod/')
print('IMPORTANT: applicationId/package was NOT changed, preserving Kcanotify broadcast compatibility.')
