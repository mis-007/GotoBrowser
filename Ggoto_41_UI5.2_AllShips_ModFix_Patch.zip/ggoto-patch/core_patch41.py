#!/usr/bin/env python3
"""Core exact-source patch for the user's uploaded GotoBrowser 4.1 tree."""
from pathlib import Path
import re
import shutil
import sys

JAVA = Path('app/src/main/java/com/antest1/gotobrowser')

class PatchError(RuntimeError):
    pass

def replace_once(src: str, old: str, new: str, label: str) -> str:
    count = src.count(old)
    if count != 1:
        raise PatchError(f'{label}: expected exactly 1 match, found {count}')
    return src.replace(old, new, 1)

def patch(root: Path):
    root = Path(root).resolve()
    gradle = root / 'app/build.gradle'
    resource = root / JAVA / 'Browser/ResourceProcess.java'
    kcs = root / JAVA / 'Browser/KcsInterface.java'
    utils = root / JAVA / 'Helpers/KcUtils.java'
    helper_dir = root / JAVA / 'Helpers'
    for path in (gradle, resource, kcs, utils):
        if not path.is_file():
            raise PatchError(f'Missing 4.1 source file: {path}')

    raw = {p: p.read_text(encoding='utf-8') for p in (gradle, resource, kcs, utils)}
    if not re.search(r'(?m)^\s*versionName\s+["\']4\.1["\']\s*$', raw[gradle]):
        raise PatchError('Expected clean official versionName 4.1; refusing another/already patched source')
    if 'applicationId "com.antest1.gotobrowser"' not in raw[gradle]:
        raise PatchError('applicationId differs; Kcanotify compatibility guard stopped patching')
    if (helper_dir / 'ShipGraphOverride.java').exists() or 'GGOTO-HACK-4.1' in raw[resource]:
        raise PatchError('Source already contains GGoto patch; use a clean official 4.1 source tree')

    resource_new = replace_once(
        raw[resource],
        'import com.antest1.gotobrowser.Helpers.KcUtils;',
        'import com.antest1.gotobrowser.Helpers.KcUtils;\n'
        'import com.antest1.gotobrowser.Helpers.GGotoHackLoader;',
        'ResourceProcess import')
    resource_new = replace_once(
        resource_new,
        '    private WebResourceResponse processImageDataResource(ResourceRequestInfo requestInfo, int resource_type) {\n'
        '        File file = new File(requestInfo.outputPath);\n',
        '    private WebResourceResponse processImageDataResource(ResourceRequestInfo requestInfo, int resource_type) {\n'
        '        File file = new File(requestInfo.outputPath);\n'
        '        // GGOTO-ALL-SHIPS: custom overlay does not require the official image\n'
        '        // to have downloaded. Otherwise some ships are skipped when the\n'
        '        // download fails or the original cache has not been populated.\n'
        '        if (ResourceProcess.isImage(resource_type)) {\n'
        '            File hack = GGotoHackLoader.select(context, requestInfo.path, file);\n'
        '            if (hack != null) {\n'
        '                try {\n'
        '                    return new WebResourceResponse("image/png", "binary",\n'
        '                        new BufferedInputStream(new FileInputStream(hack)));\n'
        '                } catch (IOException error) {\n'
        '                    Log.w("GGOTO-HACK", "Failed to open overlay", error);\n'
        '                }\n'
        '            }\n'
        '        }\n',
        '4.1 early overlay before official download')
    resource_new = replace_once(
        resource_new,
        '        File file = ResourcePatcher.INSTANCE.patchImageIfAvailable(context, versionTable, requestInfo.path, originalFile, updateFlag);\n'
        '        try {\n'
        '            InputStream is = new BufferedInputStream(new FileInputStream(file));',
        '        File file = ResourcePatcher.INSTANCE.patchImageIfAvailable(context, versionTable, requestInfo.path, originalFile, updateFlag);\n'
        '        // GGOTO-HACK-4.1: selected profile overlay is read-only; official cache remains untouched.\n'
        '        if (ResourceProcess.isImage(resource_type)) {\n'
        '            File hack = GGotoHackLoader.select(context, requestInfo.path, originalFile);\n'
        '            if (hack != null) file = hack;\n'
        '        }\n'
        '        try {\n'
        '            InputStream is = new BufferedInputStream(new FileInputStream(file));',
        '4.1 final local image selection')

    # Broadcast raw API to Kcanotify first, then override only the local WebView response.
    kcs_new = replace_once(
        raw[kcs],
        'import com.antest1.gotobrowser.Helpers.KcUtils;',
        'import com.antest1.gotobrowser.Helpers.KcUtils;\n'
        'import com.antest1.gotobrowser.Helpers.ShipGraphOverride;\n'
        'import com.antest1.gotobrowser.Helpers.GGotoDayNightPolicy;',
        'KcsInterface import')
    kcs_new = replace_once(
        kcs_new,
        'GotoBrowser.kcs_xhr_intercept(host,url,request,data);}',
        'GotoBrowser.kcs_xhr_intercept(host,url,request,data);'
        "if(url.indexOf('api_start2')>=0&&typeof data==='string'){"
        'response.data=GotoBrowser.gg_shipgraph_override(host,url,data);}'
        '}',
        '4.1 Axios response hook')
    kcs_new = replace_once(
        kcs_new,
        '                handler.post(() -> processXHR(url, requestHeader, responseRaw));',
        '                // GGOTO-AUTO: apply pending time change on successful port return.\n'
        '                if (url.contains("api_port/port")) {\n'
        '                    try {\n'
        '                        JsonObject packet = JsonParser.parseString(responseRaw.substring(7)).getAsJsonObject();\n'
        '                        if (packet.has("api_result") && packet.get("api_result").getAsInt() == 1) {\n'
        '                            if (GGotoDayNightPolicy.onPort(activity)) {\n'
        '                                Log.i("GGOTO-TIME", "Auto illustration profile switched at port return");\n'
        '                            }\n'
        '                        }\n'
        '                    } catch (Exception error) { Log.w("GGOTO-TIME", "Port clock check skipped", error); }\n'
        '                }\n'
        '                handler.post(() -> processXHR(url, requestHeader, responseRaw));',
        'KcsInterface port-return mode update')

    bridge_anchor = '    @JavascriptInterface\n    public void kcs_process_canvas_dataurl(String dataurl) {'
    bridge = '''    /** Alters only the local visual response after the original packet was broadcast. */
    @JavascriptInterface
    public String gg_shipgraph_override(String host, String url, String responseRaw) {
        if (!isGameHost(host) || url == null || !url.contains("api_start2")
                || responseRaw == null || !responseRaw.startsWith("svdata=")) {
            return responseRaw;
        }
        try {
            return ShipGraphOverride.apply(activity.getApplicationContext(), responseRaw);
        } catch (Throwable error) {
            Log.e("GGOTO-COORD", "Local coordinate override failed", error);
            return responseRaw;
        }
    }

'''
    kcs_new = replace_once(kcs_new, bridge_anchor, bridge + bridge_anchor, 'JavaScript bridge method')

    # Keep the third-party debug build independent of the original Firebase project.
    gradle_new = raw[gradle]
    for line in (
        "apply plugin: 'com.google.gms.google-services'",
        "apply plugin: 'com.google.firebase.crashlytics'",
        "    implementation 'com.google.firebase:firebase-crashlytics:21.0.1'",
        "    implementation 'com.google.firebase:firebase-analytics:24.0.0'",
    ):
        gradle_new = replace_once(gradle_new, line + '\n', '', 'Firebase removal ' + line)

    utils_new = raw[utils]
    utils_new = replace_once(utils_new,
        'import com.google.firebase.crashlytics.FirebaseCrashlytics;\n', '', 'Crashlytics import')
    utils_new = replace_once(utils_new,
        '    private static final FirebaseCrashlytics crashlytics = FirebaseCrashlytics.getInstance();\n',
        '', 'Crashlytics singleton')
    if utils_new.count('        crashlytics.recordException(e);') != 2:
        raise PatchError('Unexpected Crashlytics recordException count')
    utils_new = utils_new.replace('        crashlytics.recordException(e);',
                                  '        // GGoto: keep exception local; Firebase upload disabled in this custom build.')
    utils_new = replace_once(utils_new,
        '            crashlytics.log("download failed: " + e);',
        '            android.util.Log.w("GGOTO", "download failed: " + e);',
        'Crashlytics log replacement')
    if 'crashlytics.' in utils_new or 'FirebaseCrashlytics' in utils_new:
        raise PatchError('Firebase runtime reference remains in KcUtils')

    # Commit source modifications only after every anchor has passed.
    for path, content in ((resource, resource_new), (kcs, kcs_new),
                          (gradle, gradle_new), (utils, utils_new)):
        path.write_text(content, encoding='utf-8')
    shutil.copy2(Path(__file__).resolve().parent / 'GGotoHackLoader.java', helper_dir / 'GGotoHackLoader.java')
    shutil.copy2(Path(__file__).resolve().parent / 'ShipGraphOverride.java', helper_dir / 'ShipGraphOverride.java')
    shutil.copy2(Path(__file__).resolve().parent / 'GGotoModImporter.java', helper_dir / 'GGotoModImporter.java')
    shutil.copy2(Path(__file__).resolve().parent / 'GGotoDayNightPolicy.java', helper_dir / 'GGotoDayNightPolicy.java')

    changed_locales = 0
    for strings in (root / 'app/src/main/res').glob('values*/strings.xml'):
        content = strings.read_text(encoding='utf-8')
        old = '<string name="app_name">GotoBrowser</string>'
        if old in content:
            strings.write_text(content.replace(old, '<string name="app_name">Ggotobrowser</string>'), encoding='utf-8')
            changed_locales += 1
    if changed_locales == 0:
        raise PatchError('Could not find app_name in localized strings')

    print('GGOTO 4.1 core patch OK')
    print(' - automatic/manual day/night; selected profile overlays generic MOD before official')
    print(' - normal/day/night INI profiles; missing period INI inherits generic coordinates')
    print(' - official image cache and ResourcePatcher retained')
    print(' - original API broadcast to Kcanotify remains before local response override')
    print(' - Firebase Gradle/runtime references removed for custom debug build')
    print(f' - updated launcher label in {changed_locales} locale files')

if __name__ == '__main__':
    try:
        if len(sys.argv) != 2:
            raise PatchError('Usage: python3 core_patch41.py /path/to/GotoBrowser-4.1')
        patch(Path(sys.argv[1]))
    except (PatchError, OSError) as error:
        print('GGOTO 4.1 CORE PATCH ERROR: ' + str(error), file=sys.stderr)
        sys.exit(2)
