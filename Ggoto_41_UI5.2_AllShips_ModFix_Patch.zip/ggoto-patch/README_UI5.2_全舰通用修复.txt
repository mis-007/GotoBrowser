Ggotobrowser UI5.2 — 全舰普通/日间/夜间魔改兼容修复

已确认 UI5/5.1 的问题：
- 自动日间模式只读 .day.hack.png，完全忽略其他舰娘已导入的普通 .hack.png。
- 自动夜间同样忽略普通 .hack.png。
- 读图需要官方原图缓存或原图成功下载，部分船即使存在魔改文件也不显示。
- ZIP 导入仅接受 kcs2/resources/ship 形式，其他以 resources/ship、ship/full、full 等开头的包可能全部被跳过。
- 坐标 INI 仅读取一种模式，没有使用普通坐标作为通用基础，也不兼容旧 .day.hack.config.ini。

UI5.2 解决方案：
- 日间：专属 .day.hack.png > 普通 .hack.png > 官方原图；坐标也是专属 > 普通 > 官方。
- 夜间：专属 .night.hack.png > 普通 .hack.png > 官方原图；不使用日间魔改。
- 手动普通：只用 .hack.png 和 .config.ini。
- 自定义日夜时间 08:00/23:00；一键导入普通/日间/夜间；保留包名 com.antest1.gotobrowser。
- 导入 ZIP 自动规范 PNG、INI 后缀；保留已上传的睡衣、万圣节原始 ZIP 处理。
- 增加兼容 resources/ship、ship/full、full/full_dmg/full_x2 等有明确分组的 ZIP。
- 对于没有路径的单张裸 PNG，无法确定它属于 full 还是 full_dmg，不进行不可靠猜测。
- 导入后刷新游戏以让游戏重新请求立绘和 api_start2 坐标。

重要安装说明：
保留包名不代表一定能覆盖安装。旧版 APK 的原签名密钥缺失时，Android 仍会禁止覆盖安装。
这个构建 YAML 在没有签名 Secret 时会生成 Debug APK，不会因缺少密钥而提前中止，但不能保证覆盖旧版。
