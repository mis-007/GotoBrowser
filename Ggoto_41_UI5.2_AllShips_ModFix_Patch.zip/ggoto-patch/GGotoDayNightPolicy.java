package com.antest1.gotobrowser.Helpers;

import android.content.Context;
import android.content.SharedPreferences;
import com.antest1.gotobrowser.Constants;
import com.antest1.gotobrowser.R;
import java.util.Calendar;
import java.util.Locale;

/** Single source of truth for the currently selected illustration/coordinate mode. */
public final class GGotoDayNightPolicy {
    public static final String AUTO = "auto";
    public static final String NORMAL = "normal";
    public static final String DAY = "day";
    public static final String NIGHT = "night";
    public static final String DEFAULT_DAY_START = "08:00";
    public static final String DEFAULT_NIGHT_START = "23:00";
    private static String activeAutoProfile;

    private GGotoDayNightPolicy() {}

    public static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(context.getString(R.string.preference_key), Context.MODE_PRIVATE);
    }

    /** Returns active effective profile. Auto transitions are applied only at port, not mid-battle. */
    public static synchronized String current(Context context) {
        SharedPreferences prefs = preferences(context);
        String selected = prefs.getString(Constants.PREF_MOD_GGOTO_PROFILE, AUTO);
        if (NORMAL.equals(selected) || DAY.equals(selected) || NIGHT.equals(selected)) return selected;
        if (activeAutoProfile == null) activeAutoProfile = autoNow(prefs, Calendar.getInstance());
        return activeAutoProfile;
    }

    /** Called on successful port API response, without forcing WebView navigation/reload. */
    public static synchronized boolean onPort(Context context) {
        SharedPreferences prefs = preferences(context);
        if (!AUTO.equals(prefs.getString(Constants.PREF_MOD_GGOTO_PROFILE, AUTO))) return false;
        String next = autoNow(prefs, Calendar.getInstance());
        boolean changed = activeAutoProfile != null && !activeAutoProfile.equals(next);
        activeAutoProfile = next;
        return changed;
    }

    /** Called only after explicitly changing mode or timetable in the settings UI. */
    public static synchronized void onSettingsChanged(Context context) {
        activeAutoProfile = null;
    }

    public static String autoNow(SharedPreferences prefs, Calendar calendar) {
        int day = parseTime(prefs.getString(Constants.PREF_MOD_GGOTO_DAY_START, DEFAULT_DAY_START), 8 * 60);
        int night = parseTime(prefs.getString(Constants.PREF_MOD_GGOTO_NIGHT_START, DEFAULT_NIGHT_START), 23 * 60);
        if (day == night) { day = 8 * 60; night = 23 * 60; }
        int now = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE);
        boolean isDay = day < night ? now >= day && now < night : now >= day || now < night;
        return isDay ? DAY : NIGHT;
    }

    public static int parseTime(String value, int fallback) {
        if (value == null || !value.matches("[0-2][0-9]:[0-5][0-9]")) return fallback;
        int hours = Integer.parseInt(value.substring(0, 2));
        int minutes = Integer.parseInt(value.substring(3, 5));
        return hours < 24 ? hours * 60 + minutes : fallback;
    }

    public static String formatTime(int hour, int minute) {
        return String.format(Locale.ROOT, "%02d:%02d", hour, minute);
    }
}
