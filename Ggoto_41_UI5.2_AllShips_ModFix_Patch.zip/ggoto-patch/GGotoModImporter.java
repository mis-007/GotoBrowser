package com.antest1.gotobrowser.Helpers;

import android.content.Context;
import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Locale;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Imports normal/day/night ship MOD ZIP archives into GGoto's exact runtime
 * locations. The selected button is authoritative: it determines the output
 * suffix even when the incoming archive uses another/legacy suffix.
 *
 * Image output:
 *   normal -> .hack.png
 *   day    -> .day.hack.png
 *   night  -> .night.hack.png
 *
 * INI output (INI never uses ".hack"):
 *   normal -> .config.ini
 *   day    -> .day.config.ini
 *   night  -> .night.config.ini
 *
 * Recognizes both cache/kcs2/... and wrapper/cache/cache/kcs2/... layouts.
 * Only [graph] INI files are imported. JSON sidecars are intentionally skipped.
 */
public final class GGotoModImporter {
    private static final int MAX_ENTRIES = 5000;
    private static final int MAX_ENTRY_BYTES = 24 * 1024 * 1024;
    private static final long MAX_TOTAL_BYTES = 256L * 1024L * 1024L;

    private GGotoModImporter() { }

    public static final class ImportResult {
        private final boolean success;
        private final int imageCount;
        private final int iniCount;
        private final int ignoredCount;
        private final String error;

        ImportResult(boolean success, int imageCount, int iniCount, int ignoredCount, String error) {
            this.success = success;
            this.imageCount = imageCount;
            this.iniCount = iniCount;
            this.ignoredCount = ignoredCount;
            this.error = error;
        }

        public boolean isSuccess() { return success; }
        public int getImageCount() { return imageCount; }
        public int getIniCount() { return iniCount; }
        public int getIgnoredCount() { return ignoredCount; }
        public String getError() { return error; }
    }

    public static ImportResult importZip(Context context, Uri uri, String profile) {
        if (context == null || uri == null) return fail("No ZIP file was selected.");
        if (!"normal".equals(profile) && !"day".equals(profile) && !"night".equals(profile)) {
            return fail("Unknown import profile: " + profile);
        }

        File external = context.getExternalFilesDir(null);
        if (external == null) return fail("App external files directory is unavailable.");

        File imageRoot = new File(external, "browser_cache");
        File coordRoot = new File(external, "coord_mod");
        if (!imageRoot.exists() && !imageRoot.mkdirs()) return fail("Cannot create browser_cache directory.");
        if (!coordRoot.exists() && !coordRoot.mkdirs()) return fail("Cannot create coord_mod directory.");

        int images = 0;
        int inis = 0;
        int ignored = 0;
        int entries = 0;
        long[] totalBytes = new long[]{0L};
        Set<String> written = new HashSet<>();

        try {
            InputStream source = context.getContentResolver().openInputStream(uri);
            if (source == null) return fail("Android could not open the selected file.");

            try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(source), StandardCharsets.ISO_8859_1)) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    entries++;
                    if (entries > MAX_ENTRIES) throw new IllegalArgumentException("ZIP contains too many entries.");

                    if (entry.isDirectory()) {
                        zip.closeEntry();
                        continue;
                    }

                    String[] segments = safeSegments(entry.getName());
                    if (segments == null || segments.length == 0) {
                        ignored++;
                        drainEntry(zip, totalBytes);
                        zip.closeEntry();
                        continue;
                    }

                    String leaf = segments[segments.length - 1];
                    String lower = leaf.toLowerCase(Locale.ROOT);
                    String imageRelative = relativeShipResourcePath(segments);

                    File destination = null;
                    byte[] data = null;
                    boolean image = false;

                    if (imageRelative != null && lower.endsWith(".png")) {
                        int slash = imageRelative.lastIndexOf('/');
                        String relativeDir = slash >= 0 ? imageRelative.substring(0, slash + 1) : "";
                        String targetName = normalizeImageName(leaf, profile);
                        destination = safeChild(imageRoot, relativeDir + targetName);
                        image = true;
                    } else if (isIniName(lower) && isShipIniPath(segments)) {
                        destination = safeChild(coordRoot, normalizeIniName(leaf, profile));
                    } else {
                        ignored++;
                        drainEntry(zip, totalBytes);
                        zip.closeEntry();
                        continue;
                    }

                    data = readEntry(zip, totalBytes);
                    zip.closeEntry();

                    if (image) {
                        if (!isPng(data)) {
                            ignored++;
                            continue;
                        }
                    } else if (!hasGraphSection(data)) {
                        ignored++;
                        continue;
                    }

                    String canonical = destination.getCanonicalPath();
                    if (!written.add(canonical)) {
                        ignored++;
                        continue;
                    }

                    writeAtomically(destination, data);
                    if (image) images++; else inis++;
                }
            }

            if (images == 0 && inis == 0) {
                return fail("No supported ship PNG or [graph] INI files were found. Check that this is a MOD cache ZIP.");
            }

            return new ImportResult(true, images, inis, ignored, null);
        } catch (Exception error) {
            String message = error.getMessage();
            if (message == null || message.trim().isEmpty()) message = error.getClass().getSimpleName();
            return fail(message);
        }
    }

    private static ImportResult fail(String message) {
        return new ImportResult(false, 0, 0, 0, message);
    }

    private static String[] safeSegments(String name) {
        if (name == null) return null;
        String normalized = name.replace('\\', '/');
        String[] raw = normalized.split("/");
        java.util.ArrayList<String> clean = new java.util.ArrayList<>();
        for (String part : raw) {
            if (part.isEmpty() || ".".equals(part)) continue;
            if ("..".equals(part) || part.indexOf(':') >= 0) return null;
            clean.add(part);
        }
        return clean.toArray(new String[0]);
    }

    /**
     * Accept full ShimakazeGo paths, archives with only resources/ship,
     * and hand-made archives rooted at ship/full or full/full_dmg etc.
     * We do not guess a folder for a bare PNG: filename alone cannot tell
     * full versus full_dmg without its source folder.
     */
    private static String relativeShipResourcePath(String[] segments) {
        int idx = findSequence(segments, new String[]{"kcs2", "resources", "ship"});
        if (idx >= 0 && idx + 4 <= segments.length) return joinFrom(segments, idx);
        idx = findSequence(segments, new String[]{"resources", "ship"});
        if (idx >= 0 && idx + 3 <= segments.length) {
            return "kcs2/" + joinFrom(segments, idx);
        }
        for (int i = 0; i < segments.length - 1; i++) {
            if (!"ship".equalsIgnoreCase(segments[i])) continue;
            if (i + 2 < segments.length && isKnownShipFolder(segments[i + 1])) {
                return "kcs2/resources/" + joinFrom(segments, i);
            }
        }
        for (int i = 0; i < segments.length - 1; i++) {
            if (isKnownShipFolder(segments[i])) {
                return "kcs2/resources/ship/" + joinFrom(segments, i);
            }
        }
        return null;
    }

    private static boolean isKnownShipFolder(String value) {
        String name = value.toLowerCase(Locale.ROOT);
        return "full".equals(name) || "full_dmg".equals(name)
                || "full_x2".equals(name) || "card".equals(name)
                || "card_dmg".equals(name) || "banner".equals(name)
                || "banner_dmg".equals(name) || "album_status".equals(name)
                || "supply_character".equals(name);
    }

    private static boolean isShipIniPath(String[] segments) {
        // A clearly named .config.ini is sufficient even if an author packed
        // it flat or under coord_mod/, not under cache/kcs/resources/swf/ships/.
        return segments != null && segments.length > 0;
    }

    private static int findSequence(String[] parts, String[] sequence) {
        for (int i = 0; i <= parts.length - sequence.length; i++) {
            boolean match = true;
            for (int j = 0; j < sequence.length; j++) {
                if (!sequence[j].equalsIgnoreCase(parts[i + j])) {
                    match = false;
                    break;
                }
            }
            if (match) return i;
        }
        return -1;
    }

    private static String joinFrom(String[] parts, int start) {
        StringBuilder out = new StringBuilder();
        for (int i = start; i < parts.length; i++) {
            if (out.length() > 0) out.append('/');
            out.append(parts[i]);
        }
        return out.toString();
    }

    private static String normalizeImageName(String input, String profile) {
        String lower = input.toLowerCase(Locale.ROOT);
        String base = input;
        String[] suffixes = {
                ".day.hack.png", ".night.hack.png", ".hack.png", ".png"
        };
        for (String suffix : suffixes) {
            if (lower.endsWith(suffix)) {
                base = input.substring(0, input.length() - suffix.length());
                break;
            }
        }
        String suffix = "day".equals(profile) ? ".day.hack.png"
                : "night".equals(profile) ? ".night.hack.png" : ".hack.png";
        return base + suffix;
    }

    private static boolean isIniName(String lower) {
        return lower.endsWith(".config.ini")
                || lower.endsWith(".day.config.ini")
                || lower.endsWith(".night.config.ini")
                || lower.endsWith(".day.hack.config.ini")
                || lower.endsWith(".night.hack.config.ini")
                || lower.endsWith(".hack.config.ini");
    }

    private static String normalizeIniName(String input, String profile) {
        String lower = input.toLowerCase(Locale.ROOT);
        String[] suffixes = {
                ".day.hack.config.ini",
                ".night.hack.config.ini",
                ".day.config.ini",
                ".night.config.ini",
                ".hack.config.ini",
                ".config.ini"
        };
        String base = input;
        for (String suffix : suffixes) {
            if (lower.endsWith(suffix)) {
                base = input.substring(0, input.length() - suffix.length());
                break;
            }
        }
        String suffix = "day".equals(profile) ? ".day.config.ini"
                : "night".equals(profile) ? ".night.config.ini" : ".config.ini";
        return base + suffix;
    }


    private static void drainEntry(ZipInputStream zip, long[] totalBytes) throws Exception {
        byte[] buffer = new byte[8192];
        int count;
        int entryBytes = 0;
        while ((count = zip.read(buffer)) != -1) {
            entryBytes += count;
            totalBytes[0] += count;
            if (entryBytes > MAX_ENTRY_BYTES) throw new IllegalArgumentException("A ZIP entry exceeds the 24 MB limit.");
            if (totalBytes[0] > MAX_TOTAL_BYTES) throw new IllegalArgumentException("ZIP expands beyond the 256 MB safety limit.");
        }
    }

    private static byte[] readEntry(ZipInputStream zip, long[] totalBytes) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        int entryBytes = 0;
        while ((count = zip.read(buffer)) != -1) {
            entryBytes += count;
            totalBytes[0] += count;
            if (entryBytes > MAX_ENTRY_BYTES) throw new IllegalArgumentException("A ZIP entry exceeds the 24 MB limit.");
            if (totalBytes[0] > MAX_TOTAL_BYTES) throw new IllegalArgumentException("ZIP expands beyond the 256 MB safety limit.");
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }

    private static boolean isPng(byte[] data) {
        if (data == null || data.length < 24) return false;
        byte[] signature = {(byte)137, 80, 78, 71, 13, 10, 26, 10};
        for (int i = 0; i < signature.length; i++) if (data[i] != signature[i]) return false;
        return data[12] == 'I' && data[13] == 'H' && data[14] == 'D' && data[15] == 'R'
                && (data[16] != 0 || data[17] != 0 || data[18] != 0 || data[19] != 0)
                && (data[20] != 0 || data[21] != 0 || data[22] != 0 || data[23] != 0);
    }

    private static boolean hasGraphSection(byte[] data) {
        if (data == null || data.length == 0 || data.length > 1024 * 1024) return false;
        String text = new String(data, java.nio.charset.StandardCharsets.ISO_8859_1)
                .replace("\r", "");
        for (String line : text.split("\n")) {
            String value = line.trim();
            if (value.startsWith("\u00EF\u00BB\u00BF")) value = value.substring(3).trim();
            if ("[graph]".equalsIgnoreCase(value)) return true;
        }
        return false;
    }

    private static File safeChild(File root, String relative) throws Exception {
        File child = new File(root, relative);
        String rootPath = root.getCanonicalPath();
        String childPath = child.getCanonicalPath();
        if (!childPath.startsWith(rootPath + File.separator)) {
            throw new SecurityException("Unsafe ZIP path rejected.");
        }
        return child;
    }

    private static void writeAtomically(File destination, byte[] data) throws Exception {
        File parent = destination.getParentFile();
        if (parent == null || (!parent.exists() && !parent.mkdirs())) {
            throw new IllegalStateException("Cannot create import directory.");
        }

        File temp = new File(parent, destination.getName() + ".ggoto_tmp");
        File backup = new File(parent, destination.getName() + ".ggoto_backup");
        if (temp.exists() && !temp.delete()) throw new IllegalStateException("Cannot clear temporary import file.");

        try (FileOutputStream output = new FileOutputStream(temp)) {
            output.write(data);
            output.flush();
            output.getFD().sync();
        }

        if (backup.exists() && !backup.delete()) {
            temp.delete();
            throw new IllegalStateException("Cannot clear previous backup file.");
        }
        boolean hadOriginal = destination.exists();
        if (hadOriginal && !destination.renameTo(backup)) {
            temp.delete();
            throw new IllegalStateException("Cannot replace existing MOD file: " + destination.getName());
        }
        if (!temp.renameTo(destination)) {
            if (hadOriginal && backup.exists()) backup.renameTo(destination);
            temp.delete();
            throw new IllegalStateException("Cannot finalize imported file: " + destination.getName());
        }
        if (backup.exists()) backup.delete();
    }
}
