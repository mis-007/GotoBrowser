GGotoBrowser 4.1 UI5 — 日夜自动时间 + 一键 ZIP 导入
====================================================

设置 > MODS > GGoto 魔改立绘：

一、立绘方案
日夜自动切换（默认，手机本地系统时间）
普通（强制普通）
日间（强制日间）
夜间（强制夜间）

二、自定义时间
日间开始时间：默认 08:00
夜间开始时间：默认 23:00
点击时间后使用 Android 原生时间选择器修改。两个开始时间不能相同。
自动模式在游戏首次加载时按系统本地时间选取；时段跨越后在成功返回母港 API 请求时更新策略，不强制重载整个网页。已经绘制的图片及已加载的 shipgraph 坐标可能需要游戏自行重新发起资源请求，或手动刷新游戏后才能更新显示；没有宣称强制即时改变现有 WebGL 贴图。

三、一键导入：普通/日间/夜间，导入操作绝不改变当前日夜自动/手动模式。
普通 PNG：.hack.png；INI：.config.ini
日间 PNG：.day.hack.png；INI：.day.config.ini
夜间 PNG：.night.hack.png；INI：.night.config.ini
睡衣选择夜间导入；万圣节选择日间导入。
INI 只解析 [graph]，忽略 [info]，跳过 .config.json 侧车文件。

四、资源回退
日间缺少日间魔改时显示官方图片、使用官方坐标。
夜间缺少夜间魔改时显示官方图片、使用官方坐标。
普通模式只读取 .hack.png 和 .config.ini，不交叉使用日夜文件。

五、编译
上传 Ggoto_41_UI5_AutoDayNight_Patch.zip 到仓库根目录。
上传 build-ggoto-4.1-ui5-auto-daynight.yml 到 .github/workflows/。
打开 GitHub Actions，手动运行 Build Ggotobrowser 4.1 (UI5 Auto Day Night + ZIP Import)。
Artifacts 下载 Ggotobrowser-4.1-UI5-AutoDayNight-APK。

六、测试状态
已通过真实用户提供的 4.1 源码补丁、Java 时间边界测试及 8 语言 XML 解析；未通过 Android 完整编译及真机实测。若无法覆盖安装，请备份缓存与 INI 并检查签名是否一致。
