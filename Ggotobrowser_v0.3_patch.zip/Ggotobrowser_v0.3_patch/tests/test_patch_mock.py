from pathlib import Path
import tempfile, subprocess, sys

PATCH = Path(__file__).resolve().parents[1] / 'apply_patch.py'
HELPER = Path(__file__).resolve().parents[1] / 'helper/ShipGraphOverride.java'

with tempfile.TemporaryDirectory() as td:
    r=Path(td)
    k=r/'app/src/main/java/com/antest1/gotobrowser/Browser/KcsInterface.java'
    rp=r/'app/src/main/java/com/antest1/gotobrowser/Browser/ResourceProcess.java'
    st=r/'app/src/main/res/values/strings.xml'
    k.parent.mkdir(parents=True); st.parent.mkdir(parents=True)
    k.write_text('''package x;\nimport com.antest1.gotobrowser.Helpers.KcUtils;\nimport java.util.Locale;\nclass KcsInterface {\nprivate final BrowserActivity activity;\npublic static final String AXIOS_INTERCEPT_SCRIPT = "OLD";\nKcsInterface(BrowserActivity ac){ activity = ac; }\n    @JavascriptInterface\n    public void kcs_process_canvas_dataurl(String x){}\n}\n''')
    rp.write_text('''class ResourceProcess {\n    private WebResourceResponse x(int resource_type,String out_file_path){\n        File file = getImageFile(out_file_path);\n        String log_path=out_file_path;\n        try {\n            InputStream is = new BufferedInputStream(new FileInputStream(file));\n        } catch (IOException e) {}\n        return null;\n    }\n    private File getImageFile(String path) {\n        return new File(path);\n    }\n}\n''')
    st.write_text('<resources><string name="app_name">GotoBrowser</string></resources>')
    subprocess.check_call([sys.executable, str(PATCH), str(r)])
    a=k.read_text(); b=rp.read_text(); c=st.read_text()
    assert 'kcs_shipgraph_override' in a
    assert 'getHackImageFile' in b and 'GGOTO-HACK: custom image selected' in b
    assert 'Ggotobrowser' in c
    assert (r/'app/src/main/java/com/antest1/gotobrowser/Helpers/ShipGraphOverride.java').read_text()==HELPER.read_text()
print('V0.3 PATCH MOCK TEST PASSED')
