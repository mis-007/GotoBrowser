import json, tempfile
from pathlib import Path

# Reference behavior for INI: only [graph], byte-compatible with legacy text.
def read_graph_bytes(path: Path):
    data = path.read_bytes()
    if data.startswith(b'\xef\xbb\xbf'):
        text = data[3:].decode('utf-8', errors='replace')
    elif data.startswith(b'\xff\xfe'):
        text = data[2:].decode('utf-16le', errors='replace')
    elif data.startswith(b'\xfe\xff'):
        text = data[2:].decode('utf-16be', errors='replace')
    else:
        text = data.decode('latin1')
    result, ingraph = {}, False
    for line in text.splitlines():
        line=line.strip()
        if not line or line.startswith(';') or line.startswith('#'): continue
        if line.startswith('[') and line.endswith(']'):
            ingraph = line[1:-1].strip().lower() == 'graph'
            continue
        if not ingraph or '=' not in line: continue
        k,v=line.split('=',1)
        v=v.split(';',1)[0].split('#',1)[0].strip()
        try: result[k.strip().lower()] = int(v)
        except ValueError: pass
    return result

def hack_for(original: Path):
    name = str(original)
    dot = name.rfind('.')
    base = name[:dot] if dot > 0 else name
    p=Path(base+'.hack.png')
    if p.is_file() and p.stat().st_size > 0: return p
    if dot > 0:
        p=Path(base+'.hack'+name[dot:])
        if p.is_file() and p.stat().st_size > 0: return p
    return None

with tempfile.TemporaryDirectory() as td:
    p=Path(td)
    # GBK text in [info] must not affect ASCII [graph].
    ini = p/'x.config.ini'
    ini.write_bytes(('[info]\nship_name=岛风\ngetmes=测试\nsinfo=中文\n\n[graph]\n'
                     'boko_n_left=120\nboko_n_top=-35\nbad=abc\n').encode('gbk'))
    g=read_graph_bytes(ini)
    assert g['boko_n_left']==120 and g['boko_n_top']==-35
    assert 'ship_name' not in g and 'getmes' not in g and 'sinfo' not in g

    # Official and hack coexist; hack wins but official remains unchanged.
    official=p/'abc.png'; official.write_bytes(b'OFFICIAL')
    hack=p/'abc.hack.png'; hack.write_bytes(b'HACK')
    chosen=hack_for(official)
    assert chosen == hack and official.read_bytes()==b'OFFICIAL'
    hack.unlink()
    assert hack_for(official) is None

print('V0.3 LOGIC TESTS PASSED')
