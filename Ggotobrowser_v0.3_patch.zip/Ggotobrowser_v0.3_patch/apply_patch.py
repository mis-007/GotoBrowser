from pathlib import Path
import re, shutil, sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
KCS = ROOT / 'app/src/main/java/com/antest1/gotobrowser/Browser/KcsInterface.java'
RESOURCE = ROOT / 'app/src/main/java/com/antest1/gotobrowser/Browser/ResourceProcess.java'
HELPERS = ROOT / 'app/src/main/java/com/antest1/gotobrowser/Helpers'
STRINGS = ROOT / 'app/src/main/res/values/strings.xml'
HERE = Path(__file__).resolve().parent

for required in (KCS, RESOURCE):
    if not required.exists():
        raise SystemExit(f'ERROR: GotoBrowser source root not found or source layout changed: {required}')

backup = ROOT / '_ggotobrowser_backup_v03'
backup.mkdir(exist_ok=True)
shutil.copy2(KCS, backup / 'KcsInterface.java')
shutil.copy2(RESOURCE, backup / 'ResourceProcess.java')
if STRINGS.exists(): shutil.copy2(STRINGS, backup / 'strings.xml')

HELPERS.mkdir(parents=True, exist_ok=True)
shutil.copy2(HERE / 'helper/ShipGraphOverride.java', HELPERS / 'ShipGraphOverride.java')

# ---------------------------------------------------------------------------
# 1) Coordinate override: keep original Kcanotify API broadcast, then modify
#    only the local response copy returned to the game client.
# ---------------------------------------------------------------------------
text = KCS.read_text(encoding='utf-8')

if 'import com.antest1.gotobrowser.Helpers.ShipGraphOverride;' not in text:
    anchor = 'import com.antest1.gotobrowser.Helpers.KcUtils;'
    if anchor not in text: raise SystemExit('ERROR: KcsInterface import anchor changed upstream.')
    text = text.replace(anchor, anchor + '\nimport com.antest1.gotobrowser.Helpers.ShipGraphOverride;')
if 'import java.io.File;' not in text:
    anchor = 'import java.util.Locale;'
    if anchor not in text: raise SystemExit('ERROR: KcsInterface java import anchor changed upstream.')
    text = text.replace(anchor, 'import java.io.File;\n' + anchor)

pattern = re.compile(r'public static final String AXIOS_INTERCEPT_SCRIPT\s*=\s*".*?";', re.S)
replacement = ('public static final String AXIOS_INTERCEPT_SCRIPT = '
    '"axios.interceptors.response.use(function(response){if(response.config.url.includes(\\\"kcsapi\\\")){'
    'var url=response.config.url;var request=response.config.data;var host=window.location.hostname;var data=response.data;'
    'GotoBrowser.kcs_xhr_intercept(host,url,request,data);'
    'if(url.includes(\\\"api_start2\\\")){try{response.data=GotoBrowser.kcs_shipgraph_override(url,data);}catch(e){console.error(\\\"Ggotobrowser coord mod\\\",e);}}'
    '}return response;},function(error){return Promise.reject(error);});";')
text2, count = pattern.subn(replacement, text, count=1)
if count != 1: raise SystemExit('ERROR: AXIOS_INTERCEPT_SCRIPT not found or changed upstream.')
text = text2

field_anchor = 'private final BrowserActivity activity;'
if 'private final ShipGraphOverride shipGraphOverride;' not in text:
    if field_anchor not in text: raise SystemExit('ERROR: activity field anchor changed upstream.')
    text = text.replace(field_anchor, field_anchor + '\n    private final ShipGraphOverride shipGraphOverride;', 1)

ctor_anchor = 'activity = ac;'
if 'new ShipGraphOverride' not in text:
    if ctor_anchor not in text: raise SystemExit('ERROR: constructor anchor changed upstream.')
    init = ('activity = ac;\n'
            '        File externalFiles = activity.getExternalFilesDir(null);\n'
            '        shipGraphOverride = new ShipGraphOverride(externalFiles == null ? null : new File(externalFiles, "coord_mod"));')
    text = text.replace(ctor_anchor, init, 1)

if 'public String kcs_shipgraph_override' not in text:
    anchor = '    @JavascriptInterface\n    public void kcs_process_canvas_dataurl'
    method = '''    @JavascriptInterface
    public String kcs_shipgraph_override(String url, String responseRaw) {
        if (url == null || responseRaw == null || !url.contains("api_start2")) return responseRaw;
        return shipGraphOverride.apply(responseRaw);
    }

'''
    if anchor not in text:
        idx = text.find('public void kcs_process_canvas_dataurl')
        if idx < 0: raise SystemExit('ERROR: canvas JS-interface anchor changed upstream.')
        start = text.rfind('@JavascriptInterface', 0, idx)
        if start < 0: raise SystemExit('ERROR: JavascriptInterface anchor changed upstream.')
        text = text[:start] + method + text[start:]
    else:
        text = text.replace(anchor, method + anchor, 1)

KCS.write_text(text, encoding='utf-8')

# ---------------------------------------------------------------------------
# 2) .hack.png overlay: server always downloads/updates the official file.
#    At the FINAL image-read step only, Ggotobrowser chooses sibling .hack.png
#    first. This prevents official downloads from overwriting custom art and
#    gives personal custom art priority over language-patched cache.
# ---------------------------------------------------------------------------
rp = RESOURCE.read_text(encoding='utf-8')

if 'private File getHackImageFile(String originalPath)' not in rp:
    anchor = '''    private File getImageFile(String path) {
        return new File(path);
    }
'''
    helper = '''    private File getImageFile(String path) {
        return new File(path);
    }

    /**
     * Ggotobrowser custom image overlay.
     * Example: abc.png -> abc.hack.png
     * The hack file is NEVER a download destination; it is only selected when
     * returning the final image to WebView, so official cache updates cannot
     * overwrite it.
     */
    private File getHackImageFile(String originalPath) {
        if (originalPath == null || originalPath.length() == 0) return null;

        int dot = originalPath.lastIndexOf('.');
        String base = dot > 0 ? originalPath.substring(0, dot) : originalPath;

        // ShimakazeGo / common custom-art convention: *.hack.png
        File hackPng = new File(base + ".hack.png");
        if (hackPng.isFile() && hackPng.length() > 0) return hackPng;

        // Extra compatibility for resources/custom sets using same-extension hack.
        if (dot > 0) {
            String ext = originalPath.substring(dot);
            File hackSameExt = new File(base + ".hack" + ext);
            if (hackSameExt.isFile() && hackSameExt.length() > 0) return hackSameExt;
        }
        return null;
    }
'''
    if anchor not in rp:
        raise SystemExit('ERROR: ResourceProcess getImageFile anchor changed upstream.')
    rp = rp.replace(anchor, helper, 1)

marker = 'GGOTO-HACK: custom image selected'
if marker not in rp:
    # Insert after all normal/English-patch selection is complete, immediately
    # before FileInputStream(file) opens the final resource.
    target = '''        try {
            InputStream is = new BufferedInputStream(new FileInputStream(file));
'''
    insert = '''        if (ResourceProcess.isImage(resource_type)) {
            File hackFile = getHackImageFile(out_file_path);
            if (hackFile != null) {
                file = hackFile;
                log_path = hackFile.getAbsolutePath();
                Log.e("GGOTO-HACK", "GGOTO-HACK: custom image selected: " + log_path);
            }
        }
        try {
            InputStream is = new BufferedInputStream(new FileInputStream(file));
'''
    if target not in rp:
        raise SystemExit('ERROR: ResourceProcess final image-read anchor changed upstream.')
    rp = rp.replace(target, insert, 1)

RESOURCE.write_text(rp, encoding='utf-8')

# Display name only; package/applicationId stays untouched for Kcanotify.
if STRINGS.exists():
    s = STRINGS.read_text(encoding='utf-8')
    s2, n = re.subn(r'(<string\s+name="app_name"[^>]*>)(.*?)(</string>)', r'\1Ggotobrowser\3', s, count=1, flags=re.S)
    if n:
        STRINGS.write_text(s2, encoding='utf-8')
    else:
        print('WARN: app_name string not found; app will keep the original display name.')

print('PATCH V0.3 OK')
print('1) Coordinate INI: Android/data/com.antest1.gotobrowser/files/coord_mod/')
print('2) Custom image: place <original-base>.hack.png beside the official cached image')
print('3) Priority: .hack.png > language patched cache > official browser cache')
print('4) applicationId/package unchanged: Kcanotify compatibility preserved')
