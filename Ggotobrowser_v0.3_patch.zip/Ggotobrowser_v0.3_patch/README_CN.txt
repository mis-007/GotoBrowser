Ggotobrowser v0.3 — 岛风GO资源兼容实验补丁
===========================================

本版新增
--------
1. *.hack.png 最高优先级显示
   官方缓存文件：abc.png
   魔改文件：    abc.hack.png
   两者可以长期共存。

2. 官方下载不会覆盖 hack
   GotoBrowser 仍然只把网络资源下载到 abc.png。
   abc.hack.png 从来不作为下载目标。
   最后返回图片给游戏时才检查 hack，因此官方首次下载/后续更新都不会写坏魔改文件。

3. 最终显示优先级
   abc.hack.png > KCCP/语言补丁缓存 > 官方 browser_cache

4. INI 完整兼容 [info]
   只解析 [graph]。
   [info] 中 ship_name/getmes/sinfo 全部忽略，可以整份岛风GO INI直接复制。
   无 BOM 的旧编码 INI 使用字节兼容读取，因此 [info] 中的 GBK/Shift-JIS/UTF-8 中文日文不会干扰 ASCII 坐标。

5. Kcanotify保持原链路
   applicationId 不变：com.antest1.gotobrowser
   原始 API 先交给 Kcanotify，之后才修改游戏客户端看到的 shipgraph 坐标副本。

魔改图片放哪里
--------------
放在官方缓存图片旁边，只改文件名：

官方：.../abc.png
魔改：.../abc.hack.png

注意：不要用魔改图覆盖 abc.png。
让官方 abc.png 自己正常下载/更新。

坐标INI放哪里
-------------
Android/data/com.antest1.gotobrowser/files/coord_mod/

例如：
123456789012.config.ini

INI可以原样包含：
[info]
ship_name=...
getmes=...
sinfo=...

[graph]
boko_n_left=...
boko_n_top=...
...

建议测试
--------
A. 先升级 Ggotobrowser v0.3，不放 hack，确认游戏和 Kcanotify 正常。
B. 找一张已经缓存的 abc.png，旁边复制 abc.hack.png，重启游戏页，确认显示 hack。
C. 保留两文件，触发/等待官方缓存更新，确认 abc.png 可变化而 abc.hack.png 不被覆盖。
D. 删除 abc.hack.png，确认立即回到官方/语言补丁图。
E. 把完整岛风GO .config.ini（保留 [info]）放到 coord_mod，确认坐标仍生效。

发布修改版 APK 时请遵守 GotoBrowser 上游 GPL-3.0 许可。
