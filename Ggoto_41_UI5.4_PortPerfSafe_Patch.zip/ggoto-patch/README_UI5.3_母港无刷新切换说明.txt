GGotoBrowser 4.1 UI5.3 — 无整页刷新：返回母港后自动切换日/夜魔改（预览修复）
====================================================================

已从 UI5.2 源码确认：旧代码只更新 GGotoDayNightPolicy.activeAutoProfile，
没有通知游戏 WebGL/PIXI 已缓存的纹理对象更新。因此，返回母港后可能还显示旧时段图。

UI5.3 新增：
1. 在游戏 Axios 成功收到 api_port/port 时，同步切换当前生效的日夜策略，
   而不是等待 Android 的消息队列异步切换。
2. 不做 window.location.reload，也不强制刷新整个 WebView。
3. 当渲染器提供 PIXI 纹理缓存时，使用自定义 JS 局部重新请求舰娘 PNG，
   以原有 BaseTexture 对象更新资源，尽可能刷新屏幕上已经显示的立绘。
4. 若游戏没有公开兼容的 PIXI 纹理缓存，安全跳过该操作，避免破坏游戏。
   这时只保证后续新请求的图片按正确时段选择；已有画面可能维持旧图。
5. 保留 UI5.2 的全部功能：日夜时间（默认 08:00/23:00）和手动模式、
   普通/日间/夜间魔改 ZIP 导入、PNG/INI 命名规范化、通用舰娘路径、
   普通魔改后备、旧版签名不一致时的安装提醒、Kcanotify 原包名/广播。

重要限制（必须在真机实测）：
- 此补丁的 PIXI 局部刷新在模拟纹理对象上测试成功，但未直接测试
  《舰C》WebGL 实际渲染器。真实游戏可能使用私有纹理缓存或特殊资源管理。
- api_start2 数据的坐标是游戏启动时读取的；不重新初始化游戏内部
  主数据的情况下，日夜坐标的现有画面即时更新尚不能保证。
- 测试范围：Java/Python 源码补丁应用、JS 语法和模拟纹理更新、YAML 语法；
  未在此环境运行完整 Android APK 构建和手机真机验证。

构建：
1. 将 Ggoto_41_UI5.3_PortAutoRefresh_Patch.zip 放在 GitHub 仓库根目录。
2. 将 build-ggoto-4.1-ui5.3-port-auto-refresh.yml 放在 .github/workflows/。
3. Actions 运行 Build Ggotobrowser 4.1 (UI5.3 Port Day Night No Page Reload)。
4. Artifacts 下载 Ggotobrowser-4.1-UI5.3-PortAutoRefresh-APK。

注意：新的 versionCode 比 UI5.2 的构建基数更高，仍需相同签名才能覆盖安装。
