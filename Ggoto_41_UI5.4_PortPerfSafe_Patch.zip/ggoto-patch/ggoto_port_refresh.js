/* GGoto UI5.4: one-shot, foreground-only, bounded ship illustration update.
 * Nothing polls in the background, nothing reloads the page. PIXI fallback is
 * intentionally best-effort: never force a renderer reset on unknown engines.
 */
(function () {
  'use strict';
  if (window.__ggotoPortRefresh) return;

  var MAX_IMAGES = 12;
  var MAX_SCAN = 1800;
  var GAP_MS = 140;
  var LOAD_TIMEOUT_MS = 10000;
  var generation = 0;
  var lastMode = null;
  var pendingMode = null;
  var queue = [];
  var nextTimer = null;
  var loadTimer = null;
  var activeImage = null;
  var updated = 0;

  function foreground() {
    return !document || document.visibilityState !== 'hidden';
  }

  function isShipUrl(value) {
    return typeof value === 'string' &&
      /(?:^|\/)kcs2\/resources\/ship\//i.test(value) &&
      /\.(?:png|jpg)(?:[?#]|$)/i.test(value);
  }

  function resolveUrl(texture, cacheKey) {
    var base = texture && (texture.baseTexture || texture);
    var resource = base && base.resource;
    var options = [cacheKey, base && base.imageUrl,
      resource && resource.url, resource && resource.src,
      resource && resource.source && resource.source.src];
    for (var i = 0; i < options.length; i++) {
      if (isShipUrl(options[i]) && /^(?:https?:\/\/|\/|\.\.?\/)/.test(options[i])) {
        return options[i];
      }
    }
    return null;
  }

  function setImage(base, image) {
    if (!base) return false;
    try {
      if (base.resource && base.resource.source && typeof base.resource.update === 'function') {
        base.resource.source = image;
        base.resource.update();
        if (typeof base.update === 'function') base.update();
        return true;
      }
      if (typeof base.updateSourceImage === 'function') {
        base.updateSourceImage(image);
        return true;
      }
      if (base.source && typeof base.update === 'function') {
        base.source = image;
        base.update();
        return true;
      }
    } catch (error) {
      console.warn('[GGOTO-PORT] Texture update failed:', error);
    }
    return false;
  }

  function cancelActive() {
    if (nextTimer !== null) { clearTimeout(nextTimer); nextTimer = null; }
    if (loadTimer !== null) { clearTimeout(loadTimer); loadTimer = null; }
    if (activeImage) {
      activeImage.onload = null;
      activeImage.onerror = null;
      // Cancel unfinished decoding / download if the tab becomes hidden.
      try { activeImage.src = ''; } catch (_) {}
      activeImage = null;
    }
    queue = [];
  }

  function candidates() {
    var pixi = window.PIXI;
    var caches = [];
    if (pixi) {
      if (pixi.utils && pixi.utils.TextureCache) caches.push(pixi.utils.TextureCache);
      if (pixi.TextureCache) caches.push(pixi.TextureCache);
      if (pixi.utils && pixi.utils.BaseTextureCache) caches.push(pixi.utils.BaseTextureCache);
      if (pixi.BaseTextureCache) caches.push(pixi.BaseTextureCache);
    }
    if (!caches.length) return [];
    var seen = new Set();
    var result = [];
    var scanned = 0;
    for (var c = 0; c < caches.length && scanned < MAX_SCAN; c++) {
      var cache = caches[c];
      var keys = Object.keys(cache);
      for (var i = 0; i < keys.length && scanned < MAX_SCAN; i++, scanned++) {
        var key = keys[i];
        var texture = cache[key];
        var base = texture && (texture.baseTexture || texture);
        if (!base || seen.has(base)) continue;
        var url = resolveUrl(texture, key);
        if (!url) continue;
        seen.add(base);
        // Prefer full illustrations (port portraits) over smaller, non-visible art.
        var priority = /\/ship\/full(?:_dmg|_x2)?\//i.test(url) ? 0 : 1;
        result.push({base: base, url: url, priority: priority});
      }
    }
    result.sort(function (a, b) { return a.priority - b.priority; });
    return result.slice(0, MAX_IMAGES);
  }

  function step(mode, token) {
    nextTimer = null;
    if (token !== generation) return;
    if (!foreground()) {
      pendingMode = mode;
      cancelActive();
      return;
    }
    if (!queue.length) {
      console.info('[GGOTO-PORT] One-shot refresh finished:', updated, 'ship textures');
      return;
    }
    var item = queue.shift();
    var resolved;
    try {
      resolved = new URL(item.url, window.location.href);
      resolved.searchParams.set('_ggoto_profile', mode);
      resolved.searchParams.set('_ggoto_switch', String(token));
    } catch (error) {
      nextTimer = setTimeout(function () { step(mode, token); }, GAP_MS);
      return;
    }
    var image = new Image();
    activeImage = image;
    var done = false;
    function finish(success) {
      if (done) return;
      done = true;
      if (loadTimer !== null) { clearTimeout(loadTimer); loadTimer = null; }
      image.onload = null;
      image.onerror = null;
      if (activeImage === image) activeImage = null;
      if (token !== generation) return;
      if (!foreground()) {
        pendingMode = mode;
        cancelActive();
        return;
      }
      if (success && setImage(item.base, image)) updated++;
      nextTimer = setTimeout(function () { step(mode, token); }, GAP_MS);
    }
    image.onload = function () { finish(true); };
    image.onerror = function () { finish(false); };
    loadTimer = setTimeout(function () { finish(false); }, LOAD_TIMEOUT_MS);
    image.src = resolved.href;
  }

  function run(mode) {
    if (!foreground()) { pendingMode = mode; return; }
    generation++;
    cancelActive();
    lastMode = mode;
    pendingMode = null;
    queue = candidates();
    updated = 0;
    if (!queue.length) {
      console.info('[GGOTO-PORT] No accessible ship texture cache; new requests use the new profile');
      return;
    }
    console.info('[GGOTO-PORT] Switching', mode, 'with bounded foreground texture refresh:', queue.length);
    step(mode, generation);
  }

  // An event listener is passive: no timer, polling, network or work while hidden.
  document.addEventListener('visibilitychange', function () {
    if (!foreground()) {
      if (activeImage || queue.length || nextTimer !== null) {
        pendingMode = lastMode;
        generation++;
        cancelActive();
      }
    } else if (pendingMode) {
      run(pendingMode);
    }
  });

  window.__ggotoPortRefresh = function (mode) {
    if (mode !== 'day' && mode !== 'night') return;
    if (lastMode === mode && pendingMode === null) return;
    run(mode);
  };
})();
