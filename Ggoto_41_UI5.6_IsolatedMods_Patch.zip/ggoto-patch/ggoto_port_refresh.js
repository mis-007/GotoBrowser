/* GGoto UI5.5: one-shot port cache invalidation plus bounded foreground update.
 * Nothing polls in the background, nothing reloads the page. PIXI fallback is
 * intentionally best-effort: never force a renderer reset on unknown engines.
 */
(function () {
  'use strict';
  if (window.__ggotoPortRefresh) return;

  var MAX_IMAGES = 12;
  var MAX_SCAN = 3200;
  var MAX_EVICTIONS = 96;
  var GAP_MS = 140;
  var LOAD_TIMEOUT_MS = 10000;
  var generation = 0;
  var lastMode = null;
  var pendingMode = null;
  var queue = [];
  var nextTimer = null;
  var loadTimer = null;
  var activeImage = null;
  var updated = 0;
  var invalidated = 0;
  var boundaryTimer = null;
  var clockInPort = false;
  var CLOCK_URL = '/kcsapi/api_port/port';

  function cancelBoundaryTimer() {
    if (boundaryTimer !== null) { clearTimeout(boundaryTimer); boundaryTimer = null; }
  }
  function checkClockBoundary() {
    boundaryTimer = null;
    if (!clockInPort || !foreground()) return;
    try {
      var mode = GotoBrowser.gg_port_effective_profile(window.location.hostname, CLOCK_URL);
      if (mode && window.__ggotoPortRefresh) window.__ggotoPortRefresh(mode);
      var delay = GotoBrowser.gg_next_profile_delay(window.location.hostname, CLOCK_URL);
      window.__ggotoClockArm(delay);
    } catch (error) { console.warn('[GGOTO-TIME] Local boundary check failed', error); }
  }
  // Exactly one future timer for the next boundary; no setInterval or polling.
  window.__ggotoClockArm = function (milliseconds) {
    cancelBoundaryTimer();
    clockInPort = true;
    if (!foreground()) return;
    var delay = Number(milliseconds);
    if (!isFinite(delay) || delay < 250 || delay > 86401000) return;
    boundaryTimer = setTimeout(checkClockBoundary, delay);
  };
  // Battle/map exits stop the idle-port timer; next api_port/port re-arms it.
  window.__ggotoClockLeave = function () {
    clockInPort = false;
    cancelBoundaryTimer();
  };
  window.__ggotoClockSettingsChanged = function () {
    if (clockInPort && foreground()) checkClockBoundary();
  };

  function foreground() {
    return !document || document.visibilityState !== 'hidden';
  }

  function isShipUrl(value) {
    return typeof value === 'string' &&
      /(?:^|\/)kcs2\/resources\/ship\//i.test(value) &&
      /\.(?:png|jpg)(?:[?#]|$)/i.test(value);
  }

  function resolveUrl(texture, cacheKey) {
    var base = texture && (texture.baseTexture || texture);
    var resource = base && base.resource;
    var options = [cacheKey, base && base.imageUrl,
      resource && resource.url, resource && resource.src,
      resource && resource.source && resource.source.src];
    for (var i = 0; i < options.length; i++) {
      if (isShipUrl(options[i]) && /^(?:https?:\/\/|\/|\.\.?\/)/.test(options[i])) {
        return options[i];
      }
    }
    return null;
  }

  function setImage(base, image) {
    if (!base) return false;
    try {
      if (base.resource && base.resource.source && typeof base.resource.update === 'function') {
        base.resource.source = image;
        base.resource.update();
        if (typeof base.update === 'function') base.update();
        return true;
      }
      if (typeof base.updateSourceImage === 'function') {
        base.updateSourceImage(image);
        return true;
      }
      if (base.source && typeof base.update === 'function') {
        base.source = image;
        base.update();
        return true;
      }
    } catch (error) {
      console.warn('[GGOTO-PORT] Texture update failed:', error);
    }
    return false;
  }

  function cancelActive() {
    if (nextTimer !== null) { clearTimeout(nextTimer); nextTimer = null; }
    if (loadTimer !== null) { clearTimeout(loadTimer); loadTimer = null; }
    if (activeImage) {
      activeImage.onload = null;
      activeImage.onerror = null;
      // Cancel unfinished decoding / download if the tab becomes hidden.
      try { activeImage.src = ''; } catch (_) {}
      activeImage = null;
    }
    queue = [];
  }

  function candidates() {
    var pixi = window.PIXI;
    var caches = [];
    if (pixi) {
      if (pixi.utils && pixi.utils.TextureCache) caches.push(pixi.utils.TextureCache);
      if (pixi.TextureCache) caches.push(pixi.TextureCache);
      if (pixi.utils && pixi.utils.BaseTextureCache) caches.push(pixi.utils.BaseTextureCache);
      if (pixi.BaseTextureCache) caches.push(pixi.BaseTextureCache);
    }
    if (!caches.length) return [];
    var seen = new Set();
    var result = [];
    var scanned = 0;
    for (var c = 0; c < caches.length && scanned < MAX_SCAN; c++) {
      var cache = caches[c];
      var keys = Object.keys(cache);
      for (var i = 0; i < keys.length && scanned < MAX_SCAN; i++, scanned++) {
        var key = keys[i];
        var texture = cache[key];
        var base = texture && (texture.baseTexture || texture);
        if (!base || seen.has(base)) continue;
        var url = resolveUrl(texture, key);
        if (!url) continue;
        seen.add(base);
        // Prefer full illustrations (port portraits) over smaller, non-visible art.
        var priority = /\/ship\/full(?:_dmg|_x2)?\//i.test(url) ? 0 : 1;
        // Pixi GC records the last renderer tick a texture was used. This is
        // more useful than enumerating the first 12 arbitrary cache entries.
        var lastUsed = typeof base.touched === 'number' ? base.touched : -1;
        result.push({base: base, url: url, priority: priority, lastUsed: lastUsed});
      }
    }
    result.sort(function (a, b) {
      if (a.priority !== b.priority) return a.priority - b.priority;
      return b.lastUsed - a.lastUsed;
    });
    return result.slice(0, MAX_IMAGES);
  }

  // Evict URL -> texture lookups *before* Axios releases the successful port
  // response. The game can then request the current day/night art while it is
  // rebuilding the port scene. Never destroy live BaseTexture/Sprite objects:
  // the old scene may still be rendering for a few more frames.
  function invalidateShipLookups() {
    var pixi = window.PIXI;
    if (!pixi) return -1;
    var caches = [
      pixi.utils && pixi.utils.TextureCache,
      pixi.utils && pixi.utils.BaseTextureCache,
      pixi.TextureCache,
      pixi.BaseTextureCache
    ];
    var scanned = 0;
    var seenCaches = [];
    var matches = [];
    for (var c = 0; c < caches.length && scanned < MAX_SCAN; c++) {
      var cache = caches[c];
      if (!cache || seenCaches.indexOf(cache) >= 0) continue;
      seenCaches.push(cache);
      var keys = Object.keys(cache);
      for (var i = 0; i < keys.length && scanned < MAX_SCAN; i++, scanned++) {
        var key = keys[i];
        var texture = cache[key];
        var url = resolveUrl(texture, key);
        // Restrict invalidation to the large port-illustration families, not
        // small icons / character portraits / UI assets from other scenes.
        if (!url || !/\/ship\/full(?:_dmg|_x2)?\//i.test(url)) continue;
        var base = texture && (texture.baseTexture || texture);
        var lastUsed = base && typeof base.touched === 'number' ? base.touched : -1;
        matches.push({cache: cache, key: key, lastUsed: lastUsed});
      }
    }
    matches.sort(function (a, b) { return b.lastUsed - a.lastUsed; });
    var count = 0;
    // Only change the cache index; NEVER destroy live textures, and never
    // invalidate an unbounded number of unrelated game assets.
    for (var m = 0; m < matches.length && count < MAX_EVICTIONS; m++) {
      try { delete matches[m].cache[matches[m].key]; count++; } catch (_) {}
    }
    return count;
  }

  function step(mode, token) {
    nextTimer = null;
    if (token !== generation) return;
    if (!foreground()) {
      pendingMode = mode;
      cancelActive();
      return;
    }
    if (!queue.length) {
      console.info('[GGOTO-PORT] One-shot refresh finished:', updated, 'ship textures');
      return;
    }
    var item = queue.shift();
    var resolved;
    try {
      resolved = new URL(item.url, window.location.href);
      resolved.searchParams.set('_ggoto_profile', mode);
      resolved.searchParams.set('_ggoto_switch', String(token));
    } catch (error) {
      nextTimer = setTimeout(function () { step(mode, token); }, GAP_MS);
      return;
    }
    var image = new Image();
    activeImage = image;
    var done = false;
    function finish(success) {
      if (done) return;
      done = true;
      if (loadTimer !== null) { clearTimeout(loadTimer); loadTimer = null; }
      image.onload = null;
      image.onerror = null;
      if (activeImage === image) activeImage = null;
      if (token !== generation) return;
      if (!foreground()) {
        pendingMode = mode;
        cancelActive();
        return;
      }
      if (success && setImage(item.base, image)) updated++;
      nextTimer = setTimeout(function () { step(mode, token); }, GAP_MS);
    }
    image.onload = function () { finish(true); };
    image.onerror = function () { finish(false); };
    loadTimer = setTimeout(function () { finish(false); }, LOAD_TIMEOUT_MS);
    image.src = resolved.href;
  }

  function run(mode) {
    if (!foreground()) { pendingMode = mode; return; }
    generation++;
    cancelActive();
    lastMode = mode;
    pendingMode = null;
    queue = candidates();
    invalidated = invalidateShipLookups();
    updated = 0;
    console.info('[GGOTO-PORT] Cache lookup invalidations:', invalidated,
      'live texture candidates:', queue.length);
    if (!queue.length) {
      console.warn('[GGOTO-PORT] No accessible cached ship textures; port cache invalidation:', invalidated,
        'The game may keep ship images in a private loader that this patch cannot reach.');
      return;
    }
    console.info('[GGOTO-PORT] Switching', mode, 'with bounded foreground texture refresh:', queue.length);
    step(mode, generation);
  }

  // An event listener is passive: no timer, polling, network or work while hidden.
  document.addEventListener('visibilitychange', function () {
    if (!foreground()) {
      cancelBoundaryTimer();
      if (activeImage || queue.length || nextTimer !== null) {
        pendingMode = lastMode;
        generation++;
        cancelActive();
      }
    } else {
      if (pendingMode) run(pendingMode);
      if (clockInPort) checkClockBoundary();
    }
  });

  window.__ggotoPortRefresh = function (mode) {
    if (mode !== 'day' && mode !== 'night') return;
    if (lastMode === mode && pendingMode === null) return;
    run(mode);
  };
})();
