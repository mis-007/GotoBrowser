package com.antest1.gotobrowser.Helpers;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

/** Dedicated, app-private-to-external-files MOD tree, separate from official cache.
 * <externalFiles>/GGotoMods/{normal,day,night}/{kcs2/resources/ship,coords}/...
 * No official file is read or overwritten by this class. Legacy *.hack.png and
 * *.config.ini imports are migrated into their corresponding profile once.
 */
public final class GGotoModStore {
    private static final String TAG = "GGOTO-MODSTORE";
    private static final String ROOT = "GGotoMods";
    private static final String NORMAL = "normal";
    private static final String DAY = "day";
    private static final String NIGHT = "night";

    private GGotoModStore() {}

    private static String validProfile(String profile) {
        return DAY.equals(profile) ? DAY : NIGHT.equals(profile) ? NIGHT : NORMAL;
    }

    public static File root(Context context) {
        File external = context.getExternalFilesDir(null);
        return external == null ? null : new File(external, ROOT);
    }

    public static File profileRoot(Context context, String profile) {
        File root = root(context);
        return root == null ? null : new File(root, validProfile(profile));
    }

    public static File imageRoot(Context context, String profile) {
        File parent = profileRoot(context, profile);
        return parent == null ? null : new File(parent, "kcs2/resources/ship");
    }

    public static File coordRoot(Context context, String profile) {
        File parent = profileRoot(context, profile);
        return parent == null ? null : new File(parent, "coords");
    }

    public static String imageSuffix(String profile) {
        return DAY.equals(profile) ? ".day.hack.png" : NIGHT.equals(profile) ? ".night.hack.png" : ".hack.png";
    }

    public static String iniSuffix(String profile) {
        return DAY.equals(profile) ? ".day.config.ini" : NIGHT.equals(profile) ? ".night.config.ini" : ".config.ini";
    }

    public static String iniProfile(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".day.config.ini") || n.endsWith(".day.hack.config.ini")) return DAY;
        if (n.endsWith(".night.config.ini") || n.endsWith(".night.hack.config.ini")) return NIGHT;
        return NORMAL;
    }

    public static String iniBase(String filename) {
        String n = filename.toLowerCase(Locale.ROOT);
        String[] suffixes = {".day.hack.config.ini", ".night.hack.config.ini", ".day.config.ini",
                ".night.config.ini", ".hack.config.ini", ".config.ini"};
        for (String suffix : suffixes) {
            if (n.endsWith(suffix)) return filename.substring(0, filename.length() - suffix.length());
        }
        return null;
    }

    /** The relative path MUST begin with ship/<known resource family>/... . */
    public static File imagePath(Context context, String profile, String path) throws IOException {
        File root = imageRoot(context, profile);
        if (root == null || path == null) return null;
        String p = path.replace('\\', '/');
        String prefix = "kcs2/resources/ship/";
        int idx = p.indexOf(prefix);
        if (idx < 0) return null;
        String relative = p.substring(idx + prefix.length());
        if (!relative.matches("[A-Za-z0-9_./-]+") || relative.contains("..") || relative.startsWith("/")) return null;
        String[] parts = relative.split("/");
        if (parts.length != 2 || !knownFolder(parts[0])) return null;
        File child = new File(root, relative);
        if (!child.getCanonicalPath().startsWith(root.getCanonicalPath() + File.separator)) return null;
        return child;
    }

    private static boolean knownFolder(String n) {
        switch (n) {
            case "full": case "full_dmg": case "full_x2": case "card": case "card_dmg":
            case "banner": case "banner_dmg": case "album_status": case "supply_character":
                return true;
            default: return false;
        }
    }

    public static File imageForRequest(Context context, String requestPath, String profile,
                                       File legacyOfficialCachePath) {
        String suffix = imageSuffix(profile);
        try {
            File expected = imagePath(context, profile, requestPath);
            if (expected == null) return null;
            String base = expected.getName();
            String lower = base.toLowerCase(Locale.ROOT);
            if (!lower.endsWith(".png") && !lower.endsWith(".jpg")) return null;
            File dest = new File(expected.getParentFile(), base.substring(0, base.length() - 4) + suffix);
            if (dest.isFile() && dest.canRead()) return dest;

            // One-time lazy migration of imports produced by UI5.5 or earlier.
            File ext = context.getExternalFilesDir(null);
            if (ext != null) {
                File old = imagePathUnder(new File(ext, "browser_cache"), requestPath, suffix);
                if (old != null && old.isFile()) moveLegacy(old, dest);
            }
            // Some older manual installations placed the file next to the cache.
            if (!dest.isFile() && legacyOfficialCachePath != null) {
                String path = legacyOfficialCachePath.getAbsolutePath();
                if (path.toLowerCase(Locale.ROOT).endsWith(".png")
                        || path.toLowerCase(Locale.ROOT).endsWith(".jpg")) {
                    File old = new File(path.substring(0, path.length() - 4) + suffix);
                    if (old.isFile()) moveLegacy(old, dest);
                }
            }
            return dest.isFile() && dest.canRead() ? dest : null;
        } catch (Exception e) {
            Log.w(TAG, "MOD image lookup failed", e);
            return null;
        }
    }

    private static File imagePathUnder(File root, String requestPath, String suffix) throws IOException {
        String prefix = "kcs2/resources/ship/";
        int idx = requestPath.indexOf(prefix);
        if (idx < 0) return null;
        String sub = requestPath.substring(idx);
        if (!sub.matches("[A-Za-z0-9_./-]+") || sub.contains("..")
                || !(sub.endsWith(".png") || sub.endsWith(".jpg"))) return null;
        File old = new File(root, sub.substring(0, sub.length() - 4) + suffix);
        return old.getCanonicalPath().startsWith(root.getCanonicalPath() + File.separator) ? old : null;
    }

    /** Rename on same filesystem; copy+fsync is fallback. Never alter official PNG. */
    private static boolean moveLegacy(File source, File dest) {
        if (dest.isFile()) return true;
        File parent = dest.getParentFile();
        if (parent == null || (!parent.isDirectory() && !parent.mkdirs())) return false;
        if (source.renameTo(dest)) return true;
        File temp = new File(parent, dest.getName() + ".migration_tmp");
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(temp)) {
            byte[] buf = new byte[32768];
            int read;
            while ((read = in.read(buf)) >= 0) out.write(buf, 0, read);
            out.getFD().sync();
        } catch (IOException e) { temp.delete(); Log.w(TAG, "Migration read error", e); return false; }
        if (!temp.renameTo(dest)) { temp.delete(); return false; }
        if (!source.delete()) Log.w(TAG, "Legacy MOD retained: " + source.getName());
        return true;
    }

    /** Migrate legacy coordinates once from old coord_mod to profile-specific dirs.
     * Fast after the first run: the old directory becomes empty.
     */
    public static void migrateLegacyCoordinates(Context context) {
        File ext = context.getExternalFilesDir(null);
        if (ext == null) return;
        File[] legacyRoots = {
                new File(ext, "coord_mod"),
                new File(ext, "browser_cache/kcs/resources/swf/ships")
        };
        for (File oldRoot : legacyRoots) {
            File[] files = oldRoot.listFiles();
            if (files == null) continue;
            for (File source : files) {
                if (!source.isFile()) continue;
                String base = iniBase(source.getName());
                if (base == null || !base.matches("[A-Za-z0-9_-]+")) continue;
                String profile = iniProfile(source.getName());
                File dir = coordRoot(context, profile);
                if (dir == null) continue;
                File target = new File(dir, base + iniSuffix(profile));
                if (target.exists()) continue; // New import always wins.
                moveLegacy(source, target);
            }
        }
    }
}
