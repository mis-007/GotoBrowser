Ggotobrowser 4.1 UI5.6 — 独立魔改目录 + 手机本地时钟校准
===================================================

一、独立目录（官方 browser_cache 不存新魔改）
Android/data/com.antest1.gotobrowser/files/GGotoMods/
  normal/kcs2/resources/ship/{full,full_dmg,full_x2,...}/*.hack.png
  normal/coords/*.config.ini
  day/kcs2/resources/ship/{full,full_dmg,full_x2,...}/*.day.hack.png
  day/coords/*.day.config.ini
  night/kcs2/resources/ship/{full,full_dmg,full_x2,...}/*.night.hack.png
  night/coords/*.night.config.ini

导入按钮选哪个模式，PNG 和 INI 就会写入同一模式的独立子目录。保留自动纠正后缀、任意舰娘、嵌套 ZIP 目录支持。
读取时先读当前模式图片，缺少时读普通 PNG；坐标优先当前模式 INI，缺少时继承普通 INI，最后读官方 shipgraph。日间和夜间互不借用。
注意：若不存在当前模式 PNG 而只有该模式 INI，INI 依然可能应用于对应 shipgraph；这是兼容“仅修改坐标”的原有能力。

旧版资料迁移：
- 旧 browser_cache/kcs2/resources/ship/.../*.hack.png（日/夜亦同）首次读取时迁移进 GGotoMods 对应目录。
- 旧 coord_mod/*.config.ini 和 browser_cache/kcs/resources/swf/ships/*.config.ini 在解析 api_start2 时迁移到 GGotoMods/<模式>/coords。
- 官方原图不会被移动或覆盖。首次迁移遇到同名新文件时优先保留新文件。
- 迁移在首次读取/首次 api_start2 时进行，没有后台反复扫描线程。

二、时间修复
默认日间 08:00-23:00，夜间 23:00-08:00；使用 Android 手机本地时区及 24 小时时钟。
- 成功返回母港的 api_port/port 后重新判定日夜。
- 如一直停在母港，下一次日夜临界点只预约一次 setTimeout（不是轮询），按手机时区在临界点触发。
- 进入出击/地图/战斗或退后台时停止定时器；返回前台时立即核对手机本地时段。
- 在设置中修改时间后，如在母港则重新检测并重设边界定时器。
- logcat GGOTO-TIME 显示：本机时间、本地时区、设置阈值、旧模式、新模式，以便定位偏移。
- 不重新加载整个网页；纹理刷新仍为 UI5.4/5.5 的最多 12 张、串行、后台停止的受限更新。

三、坐标与真机限制（请重视）
已实现：所有模式的 INI 单独存放；游戏初始化时 api_start2 会按当前生效的模式读取相应坐标并修改 WebView 内的 shipgraph，不影响 Kcanotify 原始数据。
未验证：游戏长时间运行后自动切换模式时，游戏已在内存中缓存的 shipgraph 坐标能否随热切换立绘即时改变。UI5.6 不会擅自破坏游戏内部模型；真机若看到图切换但位置不变，需要检查具体游戏内部 shipgraph/ShipLoader 实例，再决定安全的热更新方式。不能宣称坐标热切换已完全实现。

四、验证情况
真实用户 ZIP：夜间 6 PNG + 2 INI，日间 9 PNG + 3 INI。
模拟其他舰娘普通 ZIP：3 PNG + 1 INI，日夜时段普通回退通过。
Java 本地单元测试：08:00、23:00 边界，分别读日/夜 30 个坐标键，老版文件迁移，所有类型文件路径。
JS 运行模拟：单次时钟定时器、切后台取消、回前台重验、离开母港取消；无 setInterval 轮询。
额外检查了 Android JavaScript bridge 解码后的 JS 语法及 YAML 构建脚本。
完整 APK Gradle 编译、真机实时坐标更新仍需 GitHub Actions 和手机实际验证。

五、签名
仍沿用 com.antest1.gotobrowser；新版本号基数 57000000，每次 GitHub run 增加。
覆盖安装必须保持与旧版 APK 的签名私钥一致；没有旧签名无法直接覆盖，这是 Android 安全要求。
