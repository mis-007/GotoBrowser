#!/usr/bin/env python3
"""Core exact-source patch for the user's uploaded GotoBrowser 4.1 tree."""
from pathlib import Path
import re
import shutil
import sys

JAVA = Path('app/src/main/java/com/antest1/gotobrowser')

class PatchError(RuntimeError):
    pass

def replace_once(src: str, old: str, new: str, label: str) -> str:
    count = src.count(old)
    if count != 1:
        raise PatchError(f'{label}: expected exactly 1 match, found {count}')
    return src.replace(old, new, 1)

def patch(root: Path):
    root = Path(root).resolve()
    gradle = root / 'app/build.gradle'
    resource = root / JAVA / 'Browser/ResourceProcess.java'
    kcs = root / JAVA / 'Browser/KcsInterface.java'
    utils = root / JAVA / 'Helpers/KcUtils.java'
    helper_dir = root / JAVA / 'Helpers'
    for path in (gradle, resource, kcs, utils):
        if not path.is_file():
            raise PatchError(f'Missing 4.1 source file: {path}')

    raw = {p: p.read_text(encoding='utf-8') for p in (gradle, resource, kcs, utils)}
    if not re.search(r'(?m)^\s*versionName\s+["\']4\.1["\']\s*$', raw[gradle]):
        raise PatchError('Expected clean official versionName 4.1; refusing another/already patched source')
    if 'applicationId "com.antest1.gotobrowser"' not in raw[gradle]:
        raise PatchError('applicationId differs; Kcanotify compatibility guard stopped patching')
    if (helper_dir / 'ShipGraphOverride.java').exists() or 'GGOTO-HACK-4.1' in raw[resource]:
        raise PatchError('Source already contains GGoto patch; use a clean official 4.1 source tree')

    resource_new = replace_once(
        raw[resource],
        'import com.antest1.gotobrowser.Helpers.KcUtils;',
        'import com.antest1.gotobrowser.Helpers.KcUtils;\n'
        'import com.antest1.gotobrowser.Helpers.GGotoHackLoader;',
        'ResourceProcess import')
    resource_new = replace_once(
        resource_new,
        '    private WebResourceResponse processImageDataResource(ResourceRequestInfo requestInfo, int resource_type) {\n'
        '        File file = new File(requestInfo.outputPath);\n',
        '    private WebResourceResponse processImageDataResource(ResourceRequestInfo requestInfo, int resource_type) {\n'
        '        File file = new File(requestInfo.outputPath);\n'
        '        // GGOTO-ALL-SHIPS: custom overlay does not require the official image\n'
        '        // to have downloaded. Otherwise some ships are skipped when the\n'
        '        // download fails or the original cache has not been populated.\n'
        '        if (ResourceProcess.isImage(resource_type)) {\n'
        '            File hack = GGotoHackLoader.select(context, requestInfo.path, file);\n'
        '            if (hack != null) {\n'
        '                try {\n'
        '                    return new WebResourceResponse("image/png", "binary",\n'
        '                        new BufferedInputStream(new FileInputStream(hack)));\n'
        '                } catch (IOException error) {\n'
        '                    Log.w("GGOTO-HACK", "Failed to open overlay", error);\n'
        '                }\n'
        '            }\n'
        '        }\n',
        '4.1 early overlay before official download')
    resource_new = replace_once(
        resource_new,
        '        File file = ResourcePatcher.INSTANCE.patchImageIfAvailable(context, versionTable, requestInfo.path, originalFile, updateFlag);\n'
        '        try {\n'
        '            InputStream is = new BufferedInputStream(new FileInputStream(file));',
        '        File file = ResourcePatcher.INSTANCE.patchImageIfAvailable(context, versionTable, requestInfo.path, originalFile, updateFlag);\n'
        '        // GGOTO-HACK-4.1: selected profile overlay is read-only; official cache remains untouched.\n'
        '        if (ResourceProcess.isImage(resource_type)) {\n'
        '            File hack = GGotoHackLoader.select(context, requestInfo.path, originalFile);\n'
        '            if (hack != null) file = hack;\n'
        '        }\n'
        '        try {\n'
        '            InputStream is = new BufferedInputStream(new FileInputStream(file));',
        '4.1 final local image selection')

    # Broadcast raw API to Kcanotify first, then override only the local WebView response.
    kcs_new = replace_once(
        raw[kcs],
        'import com.antest1.gotobrowser.Helpers.KcUtils;',
        'import com.antest1.gotobrowser.Helpers.KcUtils;\n'
        'import com.antest1.gotobrowser.Helpers.ShipGraphOverride;\n'
        'import com.antest1.gotobrowser.Helpers.GGotoDayNightPolicy;',
        'KcsInterface import')
    kcs_new = replace_once(
        kcs_new,
        'GotoBrowser.kcs_xhr_intercept(host,url,request,data);}',
        'GotoBrowser.kcs_xhr_intercept(host,url,request,data);'
        "if(url.indexOf('api_port/port')>=0&&typeof data==='string'&&"
        '/\\"api_result\\"\\\\s*:\\\\s*1(?=\\\\s*[,}])/.test(data.slice(0,256))){'
        'try{var changed=GotoBrowser.gg_port_effective_profile(host,url);'
        'if(changed&&window.__ggotoPortRefresh)window.__ggotoPortRefresh(changed);if(window.__ggotoClockArm){var d=GotoBrowser.gg_next_profile_delay(host,url);window.__ggotoClockArm(d);}}'
        "catch(e){console.warn('[GGOTO-PORT]',e);}}"
        "if((url.indexOf('api_req_map')>=0||url.indexOf('api_req_sortie')>=0||url.indexOf('api_req_battle')>=0)&&window.__ggotoClockLeave)window.__ggotoClockLeave();"
        "if(url.indexOf('api_start2')>=0&&typeof data==='string'){"
        'response.data=GotoBrowser.gg_shipgraph_override(host,url,data);}'
        '}',
        '4.1 Axios response hook')
    # The bridge must run before the game consumes api_port/port, not later
    # on Android's asynchronous packet-processing handler.

    # Called synchronously in the game frame just before Axios returns port data.
    port_bridge = r'''    /** Change clock profile on successful port return, before game rendering. */
    @JavascriptInterface
    public String gg_port_effective_profile(String host, String url) {
        // Success was already checked in the game frame on the first 256 bytes.
        // Do not copy and parse a potentially huge port response over JS bridge.
        if (!isGameHost(host) || url == null || !url.contains("api_port/port")) return "";
        try {
            if (!GGotoDayNightPolicy.onPort(activity)) return "";
            String profile = GGotoDayNightPolicy.current(activity);
            Log.i("GGOTO-TIME", "Port profile switched to: " + profile + "; notifying game textures");
            return profile;
        } catch (Exception error) {
            Log.w("GGOTO-TIME", "Port time check failed", error);
            return "";
        }
    }

'''
    # schedule only the next LOCAL device-clock boundary, no periodic polling
    next_bridge = r'''    @JavascriptInterface
    public long gg_next_profile_delay(String host, String url) {
        if (!isGameHost(host) || url == null || !url.contains("api_port/port")) return 0L;
        return GGotoDayNightPolicy.millisUntilNextBoundary(activity);
    }

'''
    bridge_anchor = '    @JavascriptInterface\n    public void kcs_process_canvas_dataurl(String dataurl) {'
    bridge = '''    /** Alters only the local visual response after the original packet was broadcast. */
    @JavascriptInterface
    public String gg_shipgraph_override(String host, String url, String responseRaw) {
        if (!isGameHost(host) || url == null || !url.contains("api_start2")
                || responseRaw == null || !responseRaw.startsWith("svdata=")) {
            return responseRaw;
        }
        try {
            return ShipGraphOverride.apply(activity.getApplicationContext(), responseRaw);
        } catch (Throwable error) {
            Log.e("GGOTO-COORD", "Local coordinate override failed", error);
            return responseRaw;
        }
    }

'''
    kcs_new = replace_once(kcs_new, bridge_anchor, port_bridge + next_bridge + bridge + bridge_anchor, 'JavaScript bridge and port-mode method')

    # Preserve all prior main.js patching; append targeted port texture updater
    # to the same script that installs the game's Axios interception.
    resource_patcher = root / JAVA / 'Browser/ResourcePatcher.kt'
    if not resource_patcher.exists():
        raise PatchError('ResourcePatcher.kt missing')
    patched_kt = replace_once(
        resource_patcher.read_text(encoding='utf-8'),
        '        patchedJs = patchedJs + MUTE_LISTEN + CAPTURE_LISTEN + "\\n" + KcsInterface.AXIOS_INTERCEPT_SCRIPT +\n'
        '                "\\n" + KcsInterface.AXIOS_HOLD_HIDDEN_SCRIPT',
        '        val ggotoPortJs = try {\n'
        '            context.assets.open("ggoto_port_refresh.js").bufferedReader(Charsets.UTF_8).use { it.readText() }\n'
        '        } catch (error: IOException) {\n'
        '            Log.w("GGOTO-PORT", "Port sprite updater missing", error)\n'
        '            ""\n'
        '        }\n'
        '        patchedJs = patchedJs + MUTE_LISTEN + CAPTURE_LISTEN + "\\n" + ggotoPortJs +\n'
        '                "\\n" + KcsInterface.AXIOS_INTERCEPT_SCRIPT +\n'
        '                "\\n" + KcsInterface.AXIOS_HOLD_HIDDEN_SCRIPT',
        'ResourcePatcher port texture refresh bootstrap')

    # Keep the third-party debug build independent of the original Firebase project.
    gradle_new = raw[gradle]
    for line in (
        "apply plugin: 'com.google.gms.google-services'",
        "apply plugin: 'com.google.firebase.crashlytics'",
        "    implementation 'com.google.firebase:firebase-crashlytics:21.0.1'",
        "    implementation 'com.google.firebase:firebase-analytics:24.0.0'",
    ):
        gradle_new = replace_once(gradle_new, line + '\n', '', 'Firebase removal ' + line)

    utils_new = raw[utils]
    utils_new = replace_once(utils_new,
        'import com.google.firebase.crashlytics.FirebaseCrashlytics;\n', '', 'Crashlytics import')
    utils_new = replace_once(utils_new,
        '    private static final FirebaseCrashlytics crashlytics = FirebaseCrashlytics.getInstance();\n',
        '', 'Crashlytics singleton')
    if utils_new.count('        crashlytics.recordException(e);') != 2:
        raise PatchError('Unexpected Crashlytics recordException count')
    utils_new = utils_new.replace('        crashlytics.recordException(e);',
                                  '        // GGoto: keep exception local; Firebase upload disabled in this custom build.')
    utils_new = replace_once(utils_new,
        '            crashlytics.log("download failed: " + e);',
        '            android.util.Log.w("GGOTO", "download failed: " + e);',
        'Crashlytics log replacement')
    if 'crashlytics.' in utils_new or 'FirebaseCrashlytics' in utils_new:
        raise PatchError('Firebase runtime reference remains in KcUtils')

    # Commit source modifications only after every anchor has passed.
    for path, content in ((resource, resource_new), (kcs, kcs_new),
                          (gradle, gradle_new), (utils, utils_new)):
        path.write_text(content, encoding='utf-8')
    shutil.copy2(Path(__file__).resolve().parent / 'GGotoHackLoader.java', helper_dir / 'GGotoHackLoader.java')
    shutil.copy2(Path(__file__).resolve().parent / 'ShipGraphOverride.java', helper_dir / 'ShipGraphOverride.java')
    shutil.copy2(Path(__file__).resolve().parent / 'GGotoModImporter.java', helper_dir / 'GGotoModImporter.java')
    shutil.copy2(Path(__file__).resolve().parent / 'GGotoDayNightPolicy.java', helper_dir / 'GGotoDayNightPolicy.java')
    shutil.copy2(Path(__file__).resolve().parent / 'GGotoModStore.java', helper_dir / 'GGotoModStore.java')
    resource_patcher.write_text(patched_kt, encoding='utf-8')
    shutil.copy2(Path(__file__).resolve().parent / 'ggoto_port_refresh.js', root / 'app/src/main/assets/ggoto_port_refresh.js')

    changed_locales = 0
    for strings in (root / 'app/src/main/res').glob('values*/strings.xml'):
        content = strings.read_text(encoding='utf-8')
        old = '<string name="app_name">GotoBrowser</string>'
        if old in content:
            strings.write_text(content.replace(old, '<string name="app_name">Ggotobrowser</string>'), encoding='utf-8')
            changed_locales += 1
    if changed_locales == 0:
        raise PatchError('Could not find app_name in localized strings')

    print('GGOTO 4.1 UI5.6 isolated MOD storage patch OK')
    print(' - automatic/manual day/night; selected profile overlays generic MOD before official')
    print(' - port mode check passes only host/url, avoiding duplicate large API JSON parsing')
    print(' - one-shot, bounded foreground texture refresh attached to patched main.js')
    print(' - normal/day/night INI profiles; missing period INI inherits generic coordinates')
    print(' - official image cache and ResourcePatcher retained')
    print(' - original API broadcast to Kcanotify remains before local response override')
    print(' - Firebase Gradle/runtime references removed for custom debug build')
    print(f' - updated launcher label in {changed_locales} locale files')

if __name__ == '__main__':
    try:
        if len(sys.argv) != 2:
            raise PatchError('Usage: python3 core_patch41.py /path/to/GotoBrowser-4.1')
        patch(Path(sys.argv[1]))
    except (PatchError, OSError) as error:
        print('GGOTO 4.1 CORE PATCH ERROR: ' + str(error), file=sys.stderr)
        sys.exit(2)
