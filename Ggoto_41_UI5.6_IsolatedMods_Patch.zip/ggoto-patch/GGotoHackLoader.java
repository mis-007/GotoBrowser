package com.antest1.gotobrowser.Helpers;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.antest1.gotobrowser.Constants;
import com.antest1.gotobrowser.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Locale;

/**
 * GGoto 4.1: read-only custom illustration overlays.
 *
 * Naming convention for an official resource "name.png":
 *   normal: name.hack.png
 *   day:    name.day.hack.png
 *   night:  name.night.hack.png
 *
 * Auto mode selects using the local clock, applying transitions on port return.
 * In day/night, use the specific variant first, then generic .hack.png,
 * then official resources. Never use the opposite time profile.
 * Official cache files are not modified.
 */
public final class GGotoHackLoader {
    private static final String TAG = "GGOTO-HACK";
    public static final String PROFILE_NORMAL = "normal";
    public static final String PROFILE_DAY = "day";
    public static final String PROFILE_NIGHT = "night";

    private GGotoHackLoader() { }

    public static String getProfile(Context context) {
        return GGotoDayNightPolicy.current(context);
    }

    /** Only the GGotoMods tree is used at runtime; old files are MOVED into
     * this tree on first read. Never read/mutate the official cache directly.
     * Mode-specific image wins; normal image is fallback, never opposite mode.
     */
    public static File select(Context context, String urlPath, File originalCache) {
        SharedPreferences pref = context.getSharedPreferences(
                context.getString(R.string.preference_key), Context.MODE_PRIVATE);
        if (!pref.getBoolean(Constants.PREF_MOD_GGOTO_HACK, true)) return null;
        if (!validAssetPath(urlPath)) return null;
        String profile = getProfile(context);
        if (PROFILE_DAY.equals(profile) || PROFILE_NIGHT.equals(profile)) {
            File selected = GGotoModStore.imageForRequest(context, urlPath, profile, originalCache);
            if (validPng(selected)) return logSelected(selected, profile);
        }
        File generic = GGotoModStore.imageForRequest(context, urlPath, PROFILE_NORMAL, originalCache);
        if (validPng(generic)) return logSelected(generic, PROFILE_NORMAL);
        return null;
    }

    private static File logSelected(File file, String profile) {
        Log.d(TAG, "Read isolated " + profile + " image: " + file.getName());
        return file;
    }

    private static boolean validAssetPath(String path) {
        if (path == null || !path.contains("/kcs2/resources/ship/")) return false;
        String lower = path.toLowerCase(Locale.ROOT);
        return (lower.endsWith(".png") || lower.endsWith(".jpg"))
                && !lower.endsWith(".hack.png");
    }

    /** Validate PNG signature and IHDR dimensions before serving a local file. */
    private static boolean validPng(File file) {
        if (file == null || !file.isFile() || !file.canRead() || file.length() < 24) return false;
        byte[] header = new byte[24];
        try (FileInputStream input = new FileInputStream(file)) {
            int pos = 0;
            while (pos < header.length) {
                int n = input.read(header, pos, header.length - pos);
                if (n < 0) return false;
                pos += n;
            }
        } catch (IOException ignored) { return false; }
        byte[] signature = {(byte)137,80,78,71,13,10,26,10};
        for (int i = 0; i < signature.length; i++) if (header[i] != signature[i]) return false;
        return header[12]=='I' && header[13]=='H' && header[14]=='D' && header[15]=='R'
                && (header[16] != 0 || header[17] != 0 || header[18] != 0 || header[19] != 0)
                && (header[20] != 0 || header[21] != 0 || header[22] != 0 || header[23] != 0);
    }
}
