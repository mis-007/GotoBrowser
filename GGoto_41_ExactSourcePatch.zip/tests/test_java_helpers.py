"""Compile new Java helper classes against tiny Android/Gson API stubs, exercise IO functions."""
from pathlib import Path
import tempfile, subprocess, shutil
BASE=Path(__file__).resolve().parents[1]
SOURCES=BASE/'ggoto-patch'
STUBS={
 'android/content/Context.java':'''package android.content;
 import java.io.File;
 public class Context { private final File root;
 public Context(File root) {this.root=root;}
 public File getExternalFilesDir(String type) {return root;}}
 ''',
 'android/util/Log.java':'''package android.util;
 public class Log {public static int i(String t,String m){return 0;}
 public static int w(String t,String m,Throwable e){return 0;}
 public static int e(String t,String m,Throwable e){return 0;}}
 ''',
 'com/google/gson/JsonElement.java':'''package com.google.gson;
 public class JsonElement {public boolean isJsonObject(){return false;}
 public boolean isJsonArray(){return false;}
 public boolean isJsonNull(){return false;}
 public JsonObject getAsJsonObject(){return null;}
 public String getAsString(){return "";}
 public int getAsInt(){return 0;}}
 ''',
 'com/google/gson/JsonObject.java':'''package com.google.gson;
 public class JsonObject extends JsonElement {
 public boolean has(String key){return false;}
 public JsonElement get(String key){return null;}
 public JsonObject getAsJsonObject(String key){return null;}
 public JsonArray getAsJsonArray(String key){return null;}
 public void add(String key,JsonElement value){}
 }
 ''',
 'com/google/gson/JsonArray.java':'''package com.google.gson;
 public class JsonArray extends JsonElement implements Iterable<JsonElement>{
 public void add(int n){} public void add(JsonElement e){}
 public int size(){return 0;}public JsonElement get(int i){return null;}
 public java.util.Iterator<JsonElement> iterator(){return java.util.Collections.emptyIterator();}}
 ''',
 'com/google/gson/JsonParser.java':'''package com.google.gson;
 public class JsonParser {public static JsonElement parseString(String input){return new JsonElement();}}
 ''',
 'com/antest1/gotobrowser/Helpers/SmokeTest.java':r'''package com.antest1.gotobrowser.Helpers;
import java.io.File;
import java.nio.file.*;
import java.util.Map;
import android.content.Context;
public class SmokeTest {
  static void ok(boolean v,String msg){if(!v)throw new IllegalStateException(msg);}
  public static void main(String[] args) throws Exception {
    File root=Files.createTempDirectory("ggoto-hack").toFile();
    File ext=new File(root,"ext");ext.mkdirs();
    File internal=new File(root,"internal/browser_cache/kcs2/resources/ship/full/111.png");
    internal.getParentFile().mkdirs();
    File hack=new File(ext,"browser_cache/kcs2/resources/ship/full/111.hack.png");
    hack.getParentFile().mkdirs();
    byte[] png=new byte[45];
    byte[] sign={(byte)137,80,78,71,13,10,26,10};
    System.arraycopy(sign,0,png,0,8);
    png[12]='I';png[13]='H';png[14]='D';png[15]='R';
    png[19]=120;png[23]=50;
    Files.write(hack.toPath(),png);
    Context ctx=new Context(ext);
    ok(GGotoHackLoader.select(ctx,"/kcs2/resources/ship/full/111.png",internal).equals(hack),"external overlay");
    ok(GGotoHackLoader.select(ctx,"/not-kcs2/111.png",internal)==null,"non-game image");
    ok(GGotoHackLoader.select(ctx,"/kcs2/../../escape.png",internal)==null,"path traversal");
    Files.delete(hack.toPath());
    File beside=new File(internal.getParentFile(),"111.hack.png");
    Files.write(beside.toPath(),png);
    ok(GGotoHackLoader.select(ctx,"/kcs2/resources/ship/full/111.png",internal).equals(beside),"adjacent fallback");
    byte[] ini="[info]\r\nship_name=".getBytes("US-ASCII");
    byte[] gb="島風".getBytes("GBK");
    byte[] tail="\r\ngetmes=test\r\n[graph]\r\nboko_n_left=210\r\nboko_n_top=-35\r\n[other]\r\nboko_n_left=999\r\n".getBytes("US-ASCII");
    byte[] body=new byte[ini.length+gb.length+tail.length];
    System.arraycopy(ini,0,body,0,ini.length);
    System.arraycopy(gb,0,body,ini.length,gb.length);
    System.arraycopy(tail,0,body,ini.length+gb.length,tail.length);
    File f=new File(root,"111.config.ini");Files.write(f.toPath(),body);
    Map<String,Integer> map=ShipGraphOverride.parseGraphOnly(f);
    ok(map.get("boko_n_left")==210,"graph coords");
    ok(map.get("boko_n_top")==-35,"top negative");
    ok(!map.containsKey("ship_name") && !map.containsKey("getmes"),"ignore info");
    System.out.println("GGOTO HELPER JAVA TEST PASS");
  }
}
 ''',
}
def main():
    with tempfile.TemporaryDirectory() as d:
        base=Path(d)
        for path,contents in STUBS.items():
            f=base/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(contents)
        (base/'com/antest1/gotobrowser/Helpers').mkdir(parents=True,exist_ok=True)
        for name in ('GGotoHackLoader.java','ShipGraphOverride.java'):
            shutil.copy(SOURCES/name, base/'com/antest1/gotobrowser/Helpers'/name)
        subprocess.run(['javac','-encoding','UTF-8','-d',str(base/'classes')]+[str(p) for p in base.rglob('*.java')],check=True)
        subprocess.run(['java','-cp',str(base/'classes'),'com.antest1.gotobrowser.Helpers.SmokeTest'],check=True)
if __name__=='__main__': main()
