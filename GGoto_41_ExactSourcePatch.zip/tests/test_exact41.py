#!/usr/bin/env python3
"""Tests against the user-provided GotoBrowser-4.1.zip."""
from pathlib import Path
import importlib.util
import tempfile
import subprocess
import zipfile
import hashlib
import re
import shutil

BASE = Path(__file__).resolve().parents[1]
SOURCE_ZIP = Path('/mnt/data/GotoBrowser-4.1.zip')
MODFILE = BASE / 'ggoto-patch' / 'patch_source41.py'
EXPECTED = {
 'app/build.gradle':'b12f67ae475a6033b9572396d6aa85b7dffbca4b164d567dea3292df6c12d90e',
 'app/src/main/java/com/antest1/gotobrowser/Browser/ResourceProcess.java':'ce24a99ec23445bd95e2671587e57defbf05b1bc64b8c7eaddd0519d9b177081',
 'app/src/main/java/com/antest1/gotobrowser/Browser/KcsInterface.java':'aaa9508ec62f2e7eb74d40c039c2a1041274a8f39e0967e1bb6d4ba629fd214a',
 'app/src/main/java/com/antest1/gotobrowser/Helpers/KcUtils.java':'c367148064f37eec189f8b800f62a78d7a0e78a344024e9744c40bee73620ae5',
}

def run():
    assert SOURCE_ZIP.is_file(), 'Test requires the actual user-uploaded 4.1 source'
    with zipfile.ZipFile(SOURCE_ZIP) as z:
        for path, checksum in EXPECTED.items():
            assert hashlib.sha256(z.read('GotoBrowser-4.1/' + path)).hexdigest() == checksum, path
        with tempfile.TemporaryDirectory() as scratch:
            scratch = Path(scratch)
            needed = [x for x in z.namelist() if any(x.endswith('/'+p) for p in EXPECTED) or '/app/src/main/res/values' in x and x.endswith('/strings.xml')]
            for name in needed:
                if name.endswith('/'):
                    continue
                dest = scratch/name
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(z.read(name))
            repo = scratch/'GotoBrowser-4.1'
            r = subprocess.run(['python3',str(MODFILE), str(repo)],capture_output=True,text=True)
            assert r.returncode == 0, r.stderr
            assert 'SOURCE PATCH OK' in r.stdout
            p=repo/'app/src/main/java/com/antest1/gotobrowser'
            rp=(p/'Browser/ResourceProcess.java').read_text()
            kc=(p/'Browser/KcsInterface.java').read_text()
            gr=(repo/'app/build.gradle').read_text()
            util=(p/'Helpers/KcUtils.java').read_text()
            assert 'ResourceRequestInfo requestInfo' in rp
            assert 'GGotoHackLoader.select(context, requestInfo.path, originalFile)' in rp
            assert rp.index('ResourcePatcher.INSTANCE.patchImageIfAvailable') < rp.index('GGotoHackLoader.select') < rp.index('new FileInputStream(file)')
            assert kc.index('GotoBrowser.kcs_xhr_intercept(host,url,request,data);') < kc.index('response.data=GotoBrowser.gg_shipgraph_override(host,url,data);')
            assert 'BROADCAST_ACTION' in kc and 'sendBroadcast(url, request, response)' in kc
            assert 'KcsInterface' in kc and 'api_start2' in kc
            assert 'com.antest1.gotobrowser' in gr and '4.1' in gr
            assert 'firebase' not in gr.lower().replace('firebase config','') or 'firebase' not in ''.join([x for x in gr.splitlines() if not x.lstrip().startswith('//')]).lower()
            assert 'FirebaseCrashlytics' not in util and 'crashlytics.' not in util
            assert (p/'Helpers/GGotoHackLoader.java').exists()
            assert (p/'Helpers/ShipGraphOverride.java').exists()
            again=subprocess.run(['python3',str(MODFILE),str(repo)],capture_output=True,text=True)
            assert again.returncode == 2 and 'Already patched' in again.stderr
            kjs=re.search(r'(?m)^\s*public static final String AXIOS_INTERCEPT_SCRIPT = (".*");', kc)
            assert kjs is not None
            import json
            js=json.loads(kjs.group(1))
            if shutil.which('node'):
                f=scratch/'interceptor.js';f.write_text(js)
                subprocess.run(['node','--check',str(f)],check=True)
    print('PASS: exact user-uploaded 4.1 source hashes')
    print('PASS: full patch against exact source signatures')
    print('PASS: modified image handler ordering and Kcanotify isolation')
    print('PASS: Firebase reference removal and local labels')
    print('PASS: safety stop on duplicate patch')
    print('PASS: Axios JavaScript parses')

if __name__=='__main__':
    run()
