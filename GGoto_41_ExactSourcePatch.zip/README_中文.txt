Ggotobrowser 4.1 — 按用户提供的 4.1 源码精准适配版
================================================
来源：用户提供的 GotoBrowser-4.1.zip，ZIP 中记录的提交：
6e78d276f0c884e80c2a5a03a0de5973a42ae969

修复重点：
1. 4.1 processImageDataResource() 使用 ResourceRequestInfo，不是 JsonObject。
2. 真正的图片文件读取发生在 ResourceProcess.serveLocalCachedImage()。
3. 调用 ResourcePatcher.kt（语言补丁）完成后，才选择本地 .hack.png。
4. 保留官方原图下载、过期检查和缓存更新；.hack.png 只读。
5. 原始 api_start2 先给 Kcanotify 的 Java 桥接，再为游戏本地副本读取 coord_mod/*.config.ini 修改坐标。
6. INI 只读取 ASCII [graph] 段，[info] 任意编码全部忽略。
7. 编译实验版同时完整删除 Firebase Gradle 插件、运行库、KcUtils 调用，避免之前的启动崩溃。
8. 保留 applicationId com.antest1.gotobrowser；应用显示名 Ggotobrowser。

GitHub 云端操作（上传两个文件即可）：
A. 将 GGoto_41_ExactSourcePatch.zip 上传到你 Fork (mis-007/GotoBrowser) 根目录。
B. 将 build-ggoto-4.1-exact.yml 上传到仓库 .github/workflows/。
C. Actions → Build Ggotobrowser 4.1 (exact source) → Run workflow。
D. 构建成功后，在 Artifacts 下载 Ggotobrowser-4.1-ExactSource-APK。
E. 这次是源码精确匹配补丁，云端会先校验四个文件的 SHA256；失败会停止，不会输出错误 APK。

手机路径：
坐标文件：
内部存储/Android/data/com.antest1.gotobrowser/files/coord_mod/123456789012.config.ini
图片（作为外部覆盖层，官方缓存是否设为外部均可）：
内部存储/Android/data/com.antest1.gotobrowser/files/browser_cache/kcs2/.../123456789012_1.hack.png
具体 ... 对应游戏官方资源 URL 在 /kcs2/ 后的目录。
例如原资源路径 /kcs2/resources/ship/full/123456789012_1.png
对应 MOD 路径 browser_cache/kcs2/resources/ship/full/123456789012_1.hack.png
如果官方缓存已经位于外部，也可以直接放在官方 .png 同目录。
注意：.hack.png 必须是正常 PNG；未找到、图片头错误或被删时自动回退普通资源。

INI 示例：
[info]
ship_name=随意中文
getmes=随意
sinfo=随意
[graph]
boko_n_left=120
boko_n_top=-35
boko_d_left=115
boko_d_top=-30
battle_n_left=80
battle_n_top=-10

首次安装：
由于不是原作者签名，同包名不能直接覆盖官方 GotoBrowser。
请先备份设置和缓存再卸载官方版；Kcanotify 不需要卸载。
若你的旧 Ggotobrowser 用了不同的 GitHub debug 签名，也可能需要卸载旧版。

本地测试：
python3 tests/test_exact41.py  （需要在本次会话中有用户原始 GotoBrowser-4.1.zip）
python3 tests/test_java_helpers.py （JDK）

状态：在所上传 4.1 源码上打补丁成功、源码结构检查通过、新 Java helper 编译及逻辑测试通过。
这里没有 Android SDK，因此完整 APK 编译和真机启动尚未验证；由 GitHub Actions 完成。
