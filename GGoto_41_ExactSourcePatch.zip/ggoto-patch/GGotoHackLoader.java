package com.antest1.gotobrowser.Helpers;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Locale;

/**
 * GGoto 4.1: user-created .hack.png is a READ-ONLY visual overlay.
 * The normal cache always writes to its original .png/.jpg path.
 */
public final class GGotoHackLoader {
    private static final String TAG = "GGOTO-HACK";
    private GGotoHackLoader() { }

    /**
     * Check the user-accessible external overlay first, then beside the actual
     * cached original file. The overlay works even when official caching is internal.
     */
    public static File select(Context context, String urlPath, File originalCache) {
        if (!validAssetPath(urlPath)) return null;
        try {
            File ext = context.getExternalFilesDir(null);
            if (ext != null) {
                File root = new File(ext, "browser_cache");
                File asset = new File(root, urlPath.substring(1));
                File hack = hackPath(asset);
                if (hack != null && containedIn(hack, root) && validPng(hack)) {
                    Log.i(TAG, "Using external overlay: " + hack.getName());
                    return hack;
                }
            }
            if (originalCache != null) {
                File beside = hackPath(originalCache);
                if (beside != null && validPng(beside)) {
                    Log.i(TAG, "Using cache-adjacent overlay: " + beside.getName());
                    return beside;
                }
            }
        } catch (Exception error) {
            Log.w(TAG, "Skipping invalid local overlay", error);
        }
        return null;
    }

    private static boolean validAssetPath(String path) {
        if (path == null || !path.startsWith("/kcs2/")) return false;
        String lower = path.toLowerCase(Locale.ROOT);
        return (lower.endsWith(".png") || lower.endsWith(".jpg"))
                && !lower.endsWith(".hack.png");
    }

    private static File hackPath(File original) {
        String path = original.getAbsolutePath();
        int slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        int dot = path.lastIndexOf('.');
        if (dot <= slash) return null;
        return new File(path.substring(0, dot) + ".hack.png");
    }

    private static boolean containedIn(File candidate, File root) throws IOException {
        String base = root.getCanonicalPath();
        String file = candidate.getCanonicalPath();
        return file.startsWith(base + File.separator);
    }

    /** Avoid a broken or unrelated file making the illustration disappear. */
    private static boolean validPng(File file) {
        if (!file.isFile() || !file.canRead() || file.length() < 24) return false;
        byte[] header = new byte[24];
        try (FileInputStream input = new FileInputStream(file)) {
            int pos = 0;
            while (pos < header.length) {
                int n = input.read(header, pos, header.length - pos);
                if (n < 0) return false;
                pos += n;
            }
        } catch (IOException ignored) { return false; }
        byte[] signature = {(byte)137,80,78,71,13,10,26,10};
        for (int i = 0; i < signature.length; i++) if (header[i] != signature[i]) return false;
        // PNG first chunk must be IHDR. Also reject zero dimensions.
        return header[12]=='I' && header[13]=='H' && header[14]=='D' && header[15]=='R'
                && (header[16] != 0 || header[17] != 0 || header[18] != 0 || header[19] != 0)
                && (header[20] != 0 || header[21] != 0 || header[22] != 0 || header[23] != 0);
    }
}
