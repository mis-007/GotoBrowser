#!/usr/bin/env python3
"""Patch the exact GotoBrowser 4.1 source (supplied Nov 10 2026).

No DEX edits, no modification to Kcanotify or any outgoing request.
Usage: python3 patch_source41.py /path/to/GotoBrowser-4.1
"""
from pathlib import Path
import re
import shutil
import sys

HERE = Path(__file__).resolve().parent
JAVA = Path('app/src/main/java/com/antest1/gotobrowser')

class PatchError(RuntimeError):
    pass


def replace_once(src: str, old: str, new: str, label: str) -> str:
    count = src.count(old)
    if count != 1:
        raise PatchError(f'{label}: expected 1 exact match in 4.1, found {count}')
    return src.replace(old, new, 1)


def patch(root: Path):
    root = Path(root).resolve()
    gradle = root / 'app/build.gradle'
    resource = root / JAVA / 'Browser/ResourceProcess.java'
    kcs = root / JAVA / 'Browser/KcsInterface.java'
    utils = root / JAVA / 'Helpers/KcUtils.java'
    helper_dir = root / JAVA / 'Helpers'
    targets = [gradle, resource, kcs, utils]
    for file in targets:
        if not file.is_file():
            raise PatchError(f'Missing 4.1 source file: {file}')
    raw = {p: p.read_text(encoding='utf-8') for p in targets}
    if not re.search(r'(?m)^\s*versionName\s+["\']4\.1["\']\s*$', raw[gradle]):
        raise PatchError('Expected exact versionName 4.1; refusing to patch another version')
    if 'applicationId "com.antest1.gotobrowser"' not in raw[gradle]:
        raise PatchError('Kcanotify app ID differs; refusing to patch')
    if (helper_dir / 'ShipGraphOverride.java').exists() or 'GGOTO-HACK-4.1' in raw[resource]:
        raise PatchError('Already patched! Always use clean official source')

    # 4.1 uses ResourceRequestInfo (NOT JsonObject), and ResourcePatcher.kt
    # is called before this point. Select the hack ONLY at the final file read.
    resource_new = replace_once(
        raw[resource],
        'import com.antest1.gotobrowser.Helpers.KcUtils;',
        'import com.antest1.gotobrowser.Helpers.KcUtils;\n'
        'import com.antest1.gotobrowser.Helpers.GGotoHackLoader;',
        'ResourceProcess import')
    resource_new = replace_once(
        resource_new,
        '        File file = ResourcePatcher.INSTANCE.patchImageIfAvailable(context, versionTable, requestInfo.path, originalFile, updateFlag);\n'
        '        try {\n'
        '            InputStream is = new BufferedInputStream(new FileInputStream(file));',
        '        File file = ResourcePatcher.INSTANCE.patchImageIfAvailable(context, versionTable, requestInfo.path, originalFile, updateFlag);\n'
        '        // GGOTO-HACK-4.1: official download and language patch finish first; hack is read-only.\n'
        '        if (ResourceProcess.isImage(resource_type)) {\n'
        '            File hack = GGotoHackLoader.select(context, requestInfo.path, originalFile);\n'
        '            if (hack != null) file = hack;\n'
        '        }\n'
        '        try {\n'
        '            InputStream is = new BufferedInputStream(new FileInputStream(file));',
        'ResourceProcess serveLocalCachedImage override')

    # The intercepted raw packet is passed to Kcanotify BEFORE game-only overrides.
    kcs_new = replace_once(raw[kcs],
        'import com.antest1.gotobrowser.Helpers.KcUtils;',
        'import com.antest1.gotobrowser.Helpers.KcUtils;\n'
        'import com.antest1.gotobrowser.Helpers.ShipGraphOverride;',
        'KcsInterface import')
    js_old = 'GotoBrowser.kcs_xhr_intercept(host,url,request,data);}'
    js_new = ('GotoBrowser.kcs_xhr_intercept(host,url,request,data);'
              "if(url.indexOf('api_start2')>=0&&typeof data==='string'){"
              'response.data=GotoBrowser.gg_shipgraph_override(host,url,data);}'
              '}')
    kcs_new = replace_once(kcs_new, js_old, js_new, '4.1 Axios script')
    bridge_anchor = '    @JavascriptInterface\n    public void kcs_process_canvas_dataurl(String dataurl) {'
    bridge = '''    /** Only the local game visual response is altered, not Kcanotify's broadcast. */
    @JavascriptInterface
    public String gg_shipgraph_override(String host, String url, String responseRaw) {
        if (!isGameHost(host) || url == null || !url.contains("api_start2")
                || responseRaw == null || !responseRaw.startsWith("svdata=")) {
            return responseRaw;
        }
        try {
            return ShipGraphOverride.apply(activity.getApplicationContext(), responseRaw);
        } catch (Throwable error) {
            Log.e("GGOTO-COORD", "Local coordinate override failed", error);
            return responseRaw;
        }
    }

'''
    kcs_new = replace_once(kcs_new, bridge_anchor, bridge + bridge_anchor, 'JavaScript bridge')

    # Production Firebase settings are not suitable for third-party debug signing.
    # Removing BOTH Gradle plugins/libs AND direct KcUtils references is required;
    # omitting only the plugins caused a startup crash in the prior custom version.
    gradle_new = raw[gradle]
    for line in (
        "apply plugin: 'com.google.gms.google-services'",
        "apply plugin: 'com.google.firebase.crashlytics'",
        "    implementation 'com.google.firebase:firebase-crashlytics:21.0.1'",
        "    implementation 'com.google.firebase:firebase-analytics:24.0.0'",
    ):
        gradle_new = replace_once(gradle_new, line + '\n', '', 'Firebase Gradle cleanup ' + line)
    utils_new = raw[utils]
    utils_new = replace_once(utils_new,
        'import com.google.firebase.crashlytics.FirebaseCrashlytics;\n', '', 'Firebase import')
    utils_new = replace_once(utils_new,
        '    private static final FirebaseCrashlytics crashlytics = FirebaseCrashlytics.getInstance();\n',
        '', 'Firebase instance')
    if utils_new.count('        crashlytics.recordException(e);') != 2:
        raise PatchError('Unexpected Crashlytics exception call count')
    utils_new = utils_new.replace('        crashlytics.recordException(e);',
                                  '        // GGoto: local log only; no Firebase crash reporting.')
    utils_new = replace_once(utils_new,
        '            crashlytics.log("download failed: " + e);',
        '            android.util.Log.w("GGOTO", "download failed: " + e);',
        'Crashlytics log')
    if 'crashlytics.' in utils_new or 'FirebaseCrashlytics' in utils_new:
        raise PatchError('Unpatched Firebase code remains')

    # Only after all checks pass do we modify files.
    changes = {resource: resource_new, kcs: kcs_new, gradle: gradle_new, utils: utils_new}
    for file, content in changes.items():
        file.write_text(content, encoding='utf-8')
    for name in ('ShipGraphOverride.java', 'GGotoHackLoader.java'):
        shutil.copy2(HERE / name, helper_dir / name)
    # Modify ALL localized labels; other app identifiers remain exactly original.
    names = 0
    for strings in (root / 'app/src/main/res').glob('values*/strings.xml'):
        content = strings.read_text(encoding='utf-8')
        old = '<string name="app_name">GotoBrowser</string>'
        if old in content:
            strings.write_text(content.replace(old, '<string name="app_name">Ggotobrowser</string>'), encoding='utf-8')
            names += 1
    if names == 0:
        raise PatchError('Could not update any launcher labels')
    print('GGOTO 4.1 SOURCE PATCH OK')
    print(' - original cache/revalidation and ResourcePatcher.kt preserved')
    print(' - .hack.png external overlay and official cache fallback')
    print(' - INI [graph] only; raw API packet still sent to Kcanotify')
    print(f' - changed launcher labels: {names}')
    print(' - Firebase Gradle + runtime references removed')

if __name__ == '__main__':
    try:
        if len(sys.argv) != 2:
            raise PatchError('Usage: patch_source41.py /path/to/GotoBrowser-4.1')
        patch(Path(sys.argv[1]))
    except (PatchError, OSError) as error:
        print('GGOTO 4.1 PATCH ERROR: ' + str(error), file=sys.stderr)
        sys.exit(2)
