GGotoBrowser 4.1 UI4 — 普通/日间/夜间魔改 ZIP 一键导入
======================================================

本补丁以用户上传的两份真实资源包作为兼容测试样本：
- 睡衣包：用户指定为“夜间魔改”
- 万圣节包：用户指定为“日间魔改”

一、设置中的三个独立导入入口
----------------------------
1. 一键导入普通魔改
2. 一键导入日间魔改（例如万圣节）
3. 一键导入夜间魔改（例如睡衣）

用户点击哪个入口，整个 ZIP 就按哪个模式统一命名；不会根据中文压缩包名称猜模式。

二、后缀规范
------------
图片：
- 普通：<原始文件名>.hack.png
- 日间：<原始文件名>.day.hack.png
- 夜间：<原始文件名>.night.hack.png

坐标 INI（INI 绝不带 .hack）：
- 普通：<原始文件名>.config.ini
- 日间：<原始文件名>.day.config.ini
- 夜间：<原始文件名>.night.config.ini

自动规范化旧命名：
- 睡衣包的 *.hack.png -> *.night.hack.png
- 睡衣包的 *.config.ini -> *.night.config.ini
- 万圣节包的 *.day.hack.png -> *.day.hack.png
- 万圣节包的 *.day.hack.config.ini -> *.day.config.ini

三、ZIP 目录兼容
----------------
自动识别：
- cache/kcs2/resources/ship/...
- cache/kcs/resources/swf/ships/...
- 任意外层目录/cache/cache/kcs2/...
- 任意外层目录/cache/cache/kcs/...

自动剥离日期/说明外层目录与重复 cache 层级。
对未设置 UTF-8 标志的旧 ZIP 文件名使用字节保真解码；实际资源路径中的 ASCII 段 kcs2/kcs 不受中文外层目录乱码影响。

四、真实上传样本测试结果
------------------------
睡衣 ZIP 选择“夜间导入”：
- 图片 6 个
- INI 2 个
- JSON sidecar 跳过 2 个
- 所有图片统一为 .night.hack.png
- 所有 INI 统一为 .night.config.ini

万圣节 ZIP 选择“日间导入”：
- 图片 9 个（full、full_dmg、full_x2）
- INI 3 个
- JSON sidecar 跳过 3 个
- 所有图片统一为 .day.hack.png
- 所有 INI 统一为 .day.config.ini

当前 GGoto 坐标覆盖模块读取 INI 的 [graph] 段；.config.json sidecar 不参与本功能，因此跳过。
INI 原有 [info] 内容保留，但坐标解析只读取 [graph]。

五、导入后的行为
----------------
导入成功后：
- 自动切换到所选普通/日间/夜间模式
- 自动开启魔改图片开关
- 自动开启魔改坐标开关
- 显示导入图片数、INI 数、跳过文件数
- 提示刷新游戏使资源生效

同名目标文件会被新导入文件替换，建议保留原始 ZIP 作为备份。

六、安全限制
------------
- ZIP 路径穿越检查，拒绝 ../ 等不安全路径
- 每个文件最大 24 MB
- ZIP 解压总量最大 256 MB
- 最多处理 5000 个条目
- 图片检查 PNG 签名和 IHDR
- INI 必须包含 [graph] 段
- 不写入或覆盖官方原始缓存；只写 browser_cache 自定义覆盖目录和 coord_mod
- JSON sidecar 跳过，不误当作 INI

七、上传 GitHub
---------------
把 Ggoto_41_DayNight_OneClickImport_UI4_Patch.zip 上传到仓库根目录。
把 build-ggoto-4.1-daynight-ui4-import.yml 上传到：
.github/workflows/

运行 Actions：
Build Ggotobrowser 4.1 (UI4 One-click Normal-Day-Night MOD Import)

Artifacts：
Ggotobrowser-4.1-DayNight-UI4-OneClickImport-APK
