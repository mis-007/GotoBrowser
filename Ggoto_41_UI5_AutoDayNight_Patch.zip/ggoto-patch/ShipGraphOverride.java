package com.antest1.gotobrowser.Helpers;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.antest1.gotobrowser.Constants;
import com.antest1.gotobrowser.R;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Local-only shipgraph coordinate override for GGoto.
 *
 * INI naming convention (for filename base "123456789012_1"):
 *   normal: 123456789012_1.config.ini
 *   day:    123456789012_1.day.config.ini
 *   night:  123456789012_1.night.config.ini
 *
 * Auto mode tracks the local device timetable. Missing selected day/night
 * INI falls back to official coordinates; no cross-mode override. [graph] only; [info]
 * and its encoding are ignored byte-for-byte.
 */
public final class ShipGraphOverride {
    private static final String TAG = "GGOTO-COORD";
    private static final String NORMAL = "normal";
    private static final String DAY = "day";
    private static final String NIGHT = "night";

    private ShipGraphOverride() { }

    public static String apply(Context context, String responseRaw) {
        if (context == null || responseRaw == null || responseRaw.isEmpty()) return responseRaw;
        SharedPreferences pref = context.getSharedPreferences(
                context.getString(R.string.preference_key), Context.MODE_PRIVATE);
        if (!pref.getBoolean(Constants.PREF_MOD_GGOTO_COORD, true)) return responseRaw;
        try {
            boolean hasPrefix = responseRaw.startsWith("svdata=");
            String json = hasPrefix ? responseRaw.substring(7) : responseRaw;
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            JsonObject apiData = root.has("api_data") && root.get("api_data").isJsonObject()
                    ? root.getAsJsonObject("api_data") : null;
            if (apiData == null || !apiData.has("api_mst_shipgraph")
                    || !apiData.get("api_mst_shipgraph").isJsonArray()) return responseRaw;

            File external = context.getExternalFilesDir(null);
            if (external == null) return responseRaw;
            File coordDir = new File(external, "coord_mod");
            if (!coordDir.isDirectory()) return responseRaw;

            String profile = GGotoDayNightPolicy.current(context);
            JsonArray graphs = apiData.getAsJsonArray("api_mst_shipgraph");
            int changed = 0;
            for (JsonElement element : graphs) {
                if (!element.isJsonObject()) continue;
                JsonObject graph = element.getAsJsonObject();
                String filename = stripImageExtension(safeString(graph, "api_filename"));
                String shipId = safeString(graph, "api_id");
                Map<String, Integer> values = loadGraphValues(coordDir, filename, shipId, profile);
                if (values.isEmpty()) continue;
                if (applyGraphValues(graph, values)) {
                    changed++;
                    Log.i(TAG, "Applied " + profile + " coordinates -> " + filename + " / " + shipId);
                }
            }
            if (changed == 0) return responseRaw;
            Log.i(TAG, "Profile=" + profile + "; overridden shipgraph entries=" + changed);
            String result = root.toString();
            return hasPrefix ? "svdata=" + result : result;
        } catch (Throwable t) {
            Log.e(TAG, "Coordinate override failed; using official data", t);
            return responseRaw;
        }
    }

    private static String stripImageExtension(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".png") || lower.endsWith(".jpg")) return name.substring(0, name.lastIndexOf('.'));
        return name;
    }

    private static String safeString(JsonObject obj, String key) {
        try {
            if (!obj.has(key) || obj.get(key).isJsonNull()) return "";
            return obj.get(key).getAsString();
        } catch (Throwable ignored) { return ""; }
    }

    /** Only use the requested profile; missing entries remain at official coordinates. */
    static Map<String, Integer> loadGraphValues(File dir, String filename, String shipId, String profile) throws Exception {
        Map<String, Integer> values = new LinkedHashMap<>();
        File selected = findIniForProfile(dir, filename, shipId, profile);
        if (selected != null) values.putAll(parseGraphOnly(selected));
        return values;
    }

    private static File findIniForProfile(File dir, String filename, String shipId, String profile) {
        String suffix = DAY.equals(profile) ? ".day.config.ini"
                : NIGHT.equals(profile) ? ".night.config.ini" : ".config.ini";
        List<String> bases = new ArrayList<>();
        if (!filename.isEmpty()) {
            bases.add(filename);
            bases.add(filename + "_1");
        }
        if (!shipId.isEmpty()) {
            bases.add(shipId);
            bases.add(shipId + "_1");
        }
        for (String base : bases) {
            File candidate = new File(dir, base + suffix);
            if (isUsableIni(candidate)) return candidate;
        }

        // ShimakazeGo packs sometimes append an extra suffix. Restrict the
        // fallback to the selected profile so day/night files cannot cross-match.
        String fallbackPrefix = !filename.isEmpty() ? filename : shipId;
        if (!fallbackPrefix.isEmpty()) {
            File[] files = dir.listFiles();
            if (files != null) {
                Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
                String prefix = fallbackPrefix.toLowerCase(Locale.ROOT);
                for (File file : files) {
                    String name = file.getName().toLowerCase(Locale.ROOT);
                    if (file.isFile() && name.startsWith(prefix)
                            && matchesIniProfile(name, profile) && isUsableIni(file)) return file;
                }
            }
        }
        return null;
    }

    private static boolean matchesIniProfile(String name, String profile) {
        if (DAY.equals(profile)) return name.endsWith(".day.config.ini");
        if (NIGHT.equals(profile)) return name.endsWith(".night.config.ini");
        return name.endsWith(".config.ini")
                && !name.endsWith(".day.config.ini")
                && !name.endsWith(".night.config.ini");
    }

    private static boolean isUsableIni(File file) {
        return file.isFile() && file.canRead() && file.length() > 0 && file.length() <= 1024 * 1024;
    }

    /** Read only the exact [graph] section; all other sections are ignored. */
    static Map<String, Integer> parseGraphOnly(File file) throws Exception {
        byte[] raw;
        try (FileInputStream in = new FileInputStream(file)) {
            raw = new byte[(int) file.length()];
            int off = 0;
            while (off < raw.length) {
                int n = in.read(raw, off, raw.length - off);
                if (n < 0) break;
                off += n;
            }
        }
        // ISO-8859-1 is a byte-preserving mapping. ASCII section names and
        // coordinate keys remain readable even if [info] is GBK/Shift-JIS.
        String content = new String(raw, StandardCharsets.ISO_8859_1);
        String[] lines = content.replace("\r", "").split("\n");
        boolean inGraph = false;
        Map<String, Integer> out = new LinkedHashMap<>();
        for (String rawLine : lines) {
            String line = rawLine.trim();
            // Strip a UTF-8 BOM if the file starts directly with [graph].
            if (line.startsWith("\u00EF\u00BB\u00BF")) line = line.substring(3).trim();
            if (line.isEmpty() || line.startsWith(";") || line.startsWith("#")) continue;
            if (line.startsWith("[") && line.endsWith("]")) {
                inGraph = "[graph]".equalsIgnoreCase(line);
                continue;
            }
            if (!inGraph) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) continue;
            String key = line.substring(0, eq).trim().toLowerCase(Locale.ROOT);
            String value = line.substring(eq + 1).trim();
            int comment = value.indexOf(';');
            int hashComment = value.indexOf('#');
            if (comment >= 0 && (hashComment < 0 || comment < hashComment)) value = value.substring(0, comment).trim();
            else if (hashComment >= 0) value = value.substring(0, hashComment).trim();
            try { out.put(key, Integer.parseInt(value)); }
            catch (NumberFormatException ignored) { /* Ignore invalid individual values. */ }
        }
        return out;
    }

    private static boolean applyGraphValues(JsonObject graph, Map<String, Integer> values) {
        boolean changed = false;
        for (String key : values.keySet()) {
            String suffix;
            if (key.endsWith("_left")) suffix = "_left";
            else if (key.endsWith("_top")) suffix = "_top";
            else continue;
            String base = key.substring(0, key.length() - suffix.length());
            String apiKey = base.startsWith("api_") ? base : "api_" + base;
            if (!graph.has(apiKey) || !graph.get(apiKey).isJsonArray()) continue;
            JsonArray old = graph.getAsJsonArray(apiKey);
            if (old.size() < 2) continue;
            int left = values.containsKey(base + "_left") ? values.get(base + "_left") : safeInt(old.get(0));
            int top = values.containsKey(base + "_top") ? values.get(base + "_top") : safeInt(old.get(1));
            JsonArray replacement = new JsonArray();
            replacement.add(left);
            replacement.add(top);
            for (int i = 2; i < old.size(); i++) replacement.add(old.get(i));
            graph.add(apiKey, replacement);
            changed = true;
        }
        return changed;
    }

    private static int safeInt(JsonElement e) {
        try { return e.getAsInt(); } catch (Throwable ignored) { return 0; }
    }
}
