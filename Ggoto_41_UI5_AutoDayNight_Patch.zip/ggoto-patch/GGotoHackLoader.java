package com.antest1.gotobrowser.Helpers;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.antest1.gotobrowser.Constants;
import com.antest1.gotobrowser.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Locale;

/**
 * GGoto 4.1: read-only custom illustration overlays.
 *
 * Naming convention for an official resource "name.png":
 *   normal: name.hack.png
 *   day:    name.day.hack.png
 *   night:  name.night.hack.png
 *
 * Auto mode selects using the local clock, applying transitions on port return.
 * In the selected day/night profile, missing files use OFFICIAL resources, not
 * custom images for the other time period. Official cache is never written here.
 */
public final class GGotoHackLoader {
    private static final String TAG = "GGOTO-HACK";
    public static final String PROFILE_NORMAL = "normal";
    public static final String PROFILE_DAY = "day";
    public static final String PROFILE_NIGHT = "night";

    private GGotoHackLoader() { }

    public static String getProfile(Context context) {
        return GGotoDayNightPolicy.current(context);
    }

    /**
     * Check the user-accessible external overlay first, then beside the actual
     * cached original file. Selected day/night variant wins; normal is fallback.
     */
    public static File select(Context context, String urlPath, File originalCache) {
        SharedPreferences pref = context.getSharedPreferences(
                context.getString(R.string.preference_key), Context.MODE_PRIVATE);
        if (!pref.getBoolean(Constants.PREF_MOD_GGOTO_HACK, true)) return null;
        if (!validAssetPath(urlPath)) return null;

        String profile = getProfile(context);
        try {
            File extRoot = null;
            File extAsset = null;
            File ext = context.getExternalFilesDir(null);
            if (ext != null) {
                extRoot = new File(ext, "browser_cache");
                extAsset = new File(extRoot, urlPath.substring(1));
            }

            // Selected day/night profile only; never substitute another mode.
            if (PROFILE_DAY.equals(profile) || PROFILE_NIGHT.equals(profile)) {
                String suffix = PROFILE_DAY.equals(profile) ? ".day.hack.png" : ".night.hack.png";
                File selected = profileOverlay(extAsset, suffix, extRoot);
                if (selected != null) return logSelected(selected, profile, false);
                selected = profileOverlay(originalCache, suffix, null);
                if (selected != null) return logSelected(selected, profile, true);
                return null; // Missing selected day/night image => official asset.
            }

            File selected = normalOverlay(extAsset, extRoot);
            if (selected != null) return logSelected(selected, profile, false);
            selected = normalOverlay(originalCache, null);
            if (selected != null) return logSelected(selected, profile, true);
        } catch (Exception error) {
            Log.w(TAG, "Skipping invalid local overlay", error);
        }
        return null;
    }

    private static File profileOverlay(File original, String suffix, File allowedRoot) throws IOException {
        if (original == null) return null;
        File candidate = overlayPath(original, suffix);
        if (!validPng(candidate)) return null;
        return allowedRoot == null || containedIn(candidate, allowedRoot) ? candidate : null;
    }

    private static File normalOverlay(File original, File allowedRoot) throws IOException {
        if (original == null) return null;
        File candidate = overlayPath(original, ".hack.png");
        if (!validPng(candidate)) return null;
        return allowedRoot == null || containedIn(candidate, allowedRoot) ? candidate : null;
    }

    private static File logSelected(File selected, String profile, boolean adjacent) {
        Log.i(TAG, "Using " + (adjacent ? "cache-adjacent " : "external ")
                + profile + " overlay: " + selected.getName());
        return selected;
    }

    private static File overlayPath(File original, String suffix) {
        String path = original.getAbsolutePath();
        int slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        int dot = path.lastIndexOf('.');
        if (dot <= slash) return null;
        return new File(path.substring(0, dot) + suffix);
    }

    private static boolean validAssetPath(String path) {
        if (path == null || !path.startsWith("/kcs2/")) return false;
        String lower = path.toLowerCase(Locale.ROOT);
        return (lower.endsWith(".png") || lower.endsWith(".jpg"))
                && !lower.endsWith(".hack.png");
    }

    private static boolean containedIn(File candidate, File root) throws IOException {
        String base = root.getCanonicalPath();
        String file = candidate.getCanonicalPath();
        return file.startsWith(base + File.separator);
    }

    /** Validate PNG signature and IHDR dimensions before serving a local file. */
    private static boolean validPng(File file) {
        if (file == null || !file.isFile() || !file.canRead() || file.length() < 24) return false;
        byte[] header = new byte[24];
        try (FileInputStream input = new FileInputStream(file)) {
            int pos = 0;
            while (pos < header.length) {
                int n = input.read(header, pos, header.length - pos);
                if (n < 0) return false;
                pos += n;
            }
        } catch (IOException ignored) { return false; }
        byte[] signature = {(byte)137,80,78,71,13,10,26,10};
        for (int i = 0; i < signature.length; i++) if (header[i] != signature[i]) return false;
        return header[12]=='I' && header[13]=='H' && header[14]=='D' && header[15]=='R'
                && (header[16] != 0 || header[17] != 0 || header[18] != 0 || header[19] != 0)
                && (header[20] != 0 || header[21] != 0 || header[22] != 0 || header[23] != 0);
    }
}
