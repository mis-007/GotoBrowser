#!/usr/bin/env python3
"""Apply GGoto 4.1 UI5 patch: automatic timetable and ZIP imports."""
from pathlib import Path
import sys
from html import escape
from core_patch41 import patch as patch_core, PatchError, replace_once

JAVA = Path('app/src/main/java/com/antest1/gotobrowser')

# key order is shared across all translations below.
KEYS = [
    'settings_mod_ggoto_group',
    'settings_mod_ggoto_main_hint',
    'settings_mod_ggoto_hack',
    'settings_mod_ggoto_hack_summary',
    'settings_mod_ggoto_coord',
    'settings_mod_ggoto_coord_summary',
    'settings_mod_ggoto_profile',
    'settings_mod_ggoto_profile_normal',
    'settings_mod_ggoto_profile_normal_summary',
    'settings_mod_ggoto_profile_day',
    'settings_mod_ggoto_profile_day_summary',
    'settings_mod_ggoto_profile_night',
    'settings_mod_ggoto_profile_night_summary',
    'settings_mod_ggoto_paths',
    'settings_mod_ggoto_paths_summary',
    'settings_mod_ggoto_paths_note',
    'settings_mod_ggoto_count',
    'settings_mod_ggoto_import_group',
    'settings_mod_ggoto_import_normal',
    'settings_mod_ggoto_import_normal_summary',
    'settings_mod_ggoto_import_day',
    'settings_mod_ggoto_import_day_summary',
    'settings_mod_ggoto_import_night',
    'settings_mod_ggoto_import_night_summary',
    'settings_mod_ggoto_import_busy',
    'settings_mod_ggoto_import_result',
    'settings_mod_ggoto_import_success',
    'settings_mod_ggoto_import_failed',
]

TRANSLATIONS = {
 'values': [
  'GGoto Custom Illustrations', 'Custom ship illustrations and coordinate profiles',
  'Prefer custom .hack.png images', 'Use local custom PNG overlays; official cache is preserved (reload required)',
  'Use custom .config.ini coordinates', 'Read only [graph]; ignore [info] (reload required)',
  'Illustration profile (manual)',
  'Normal', 'Use .hack.png and .config.ini',
  'Day', 'Use .day.hack.png; day INI overrides normal coordinates',
  'Night', 'Use .night.hack.png; night INI overrides normal coordinates',
  'Where to put mod files', 'View image and INI directories',
  'Keep official PNG files. Images go under browser_cache/kcs2 using .hack.png / .day.hack.png / .night.hack.png. INI files go in coord_mod.',
  'INI files found',
  'One-click MOD ZIP import',
  'Import normal MOD',
  'Select a normal MOD cache ZIP. Files are normalized to .hack.png and .config.ini.',
  'Import daytime MOD',
  'Example: Halloween daytime pack. Files are normalized to .day.hack.png and .day.config.ini.',
  'Import nighttime MOD',
  'Example: pajamas nighttime pack. Files are normalized to .night.hack.png and .night.config.ini.',
  'Importing MOD ZIP...',
  'MOD import result',
  'Imported %1$s: %2$d images, %3$d INI files, %4$d unsupported files skipped. Refresh the game to apply.',
  'Import failed: %1$s'
 ],
 'values-zh-rCN': [
  'GGoto 魔改立绘', '自定义舰娘立绘与日夜坐标方案',
  '优先使用魔改立绘图片', '读取本地魔改 PNG，保留官方缓存（需刷新）',
  '启用魔改坐标 INI', '只读取 [graph]，忽略 [info]（需刷新）',
  '立绘方案（手动切换）',
  '普通模式', '使用 .hack.png 和 .config.ini',
  '日间模式', '优先使用 .day.hack.png；日间 INI 覆盖普通坐标，未设置项沿用普通坐标',
  '夜间模式', '优先使用 .night.hack.png；夜间 INI 覆盖普通坐标，未设置项沿用普通坐标',
  '查看魔改文件目录', '显示图片与 INI 存放位置',
  '图片放入 browser_cache/kcs2，使用 .hack.png、.day.hack.png、.night.hack.png；INI 放入 coord_mod。',
  '已发现 INI 文件数',
  '一键导入魔改 ZIP',
  '一键导入普通魔改',
  '选择普通魔改缓存 ZIP，自动统一为 .hack.png 和 .config.ini。',
  '一键导入日间魔改',
  '例如：万圣节日间包。自动统一为 .day.hack.png 和 .day.config.ini。',
  '一键导入夜间魔改',
  '例如：睡衣夜间包。自动统一为 .night.hack.png 和 .night.config.ini。',
  '正在导入魔改 ZIP…',
  '魔改导入结果',
  '导入成功：%1$s模式，立绘 %2$d 个，坐标 INI %3$d 个，跳过其他文件 %4$d 个。请刷新游戏生效。',
  '导入失败：%1$s'
 ],
 'values-zh-rTW': [
  'GGoto 自訂立繪', '自訂艦娘立繪與日夜座標方案',
  '優先使用自訂立繪圖片', '讀取本機自訂 PNG，保留官方快取（需重新整理）',
  '啟用自訂座標 INI', '只讀取 [graph]，忽略 [info]（需重新整理）',
  '立繪方案（手動切換）',
  '一般模式', '使用 .hack.png 和 .config.ini',
  '日間模式', '優先使用 .day.hack.png；日間 INI 覆蓋一般座標，未設定項沿用一般座標',
  '夜間模式', '優先使用 .night.hack.png；夜間 INI 覆蓋一般座標，未設定項沿用一般座標',
  '查看自訂檔案位置', '顯示圖片與 INI 儲存位置',
  '圖片放入 browser_cache/kcs2，使用 .hack.png、.day.hack.png、.night.hack.png；INI 放入 coord_mod。',
  '已找到的 INI 檔案',
  '一鍵匯入魔改 ZIP',
  '一鍵匯入一般魔改',
  '選擇一般魔改快取 ZIP，自動統一為 .hack.png 和 .config.ini。',
  '一鍵匯入日間魔改',
  '例如：萬聖節日間包。自動統一為 .day.hack.png 和 .day.config.ini。',
  '一鍵匯入夜間魔改',
  '例如：睡衣夜間包。自動統一為 .night.hack.png 和 .night.config.ini。',
  '正在匯入魔改 ZIP…',
  '魔改匯入結果',
  '匯入成功：%1$s模式，立繪 %2$d 個，座標 INI %3$d 個，略過其他檔案 %4$d 個。請重新整理遊戲。',
  '匯入失敗：%1$s'
 ],
 'values-ja': [
  'GGoto カスタム立ち絵', '艦娘画像と昼夜座標プロファイル',
  'カスタム立ち絵を優先', 'ローカルPNGを優先し、公式キャッシュを保持（再読み込み必要）',
  'カスタム座標INIを使用', '[graph] のみ読み込み、[info] は無視（再読み込み必要）',
  '立ち絵プロファイル（手動）',
  '通常', '.hack.png と .config.ini を使用',
  '昼', '.day.hack.png を優先し、座標は通常INIを継承して昼INIで上書き',
  '夜', '.night.hack.png を優先し、座標は通常INIを継承して夜INIで上書き',
  'MODファイルの保存先', '画像とINIのフォルダーを表示',
  '画像は browser_cache/kcs2 に .hack.png / .day.hack.png / .night.hack.png 形式で保存し、INIは coord_mod に保存します。',
  'INIファイル数',
  'MOD ZIPをワンクリックでインポート',
  '通常MODをインポート',
  '通常MODのキャッシュZIPを選択します。.hack.png と .config.ini に統一します。',
  '昼MODをインポート',
  '例：ハロウィン昼MOD。.day.hack.png と .day.config.ini に統一します。',
  '夜MODをインポート',
  '例：パジャマ夜MOD。.night.hack.png と .night.config.ini に統一します。',
  'MOD ZIPをインポート中…',
  'MODインポート結果',
  'インポート完了：%1$s、画像 %2$d 件、INI %3$d 件、その他 %4$d 件をスキップ。ゲームを再読み込みしてください。',
  'インポート失敗：%1$s'
 ],
 'values-ko': [
  'GGoto 커스텀 일러스트', '함선 이미지 및 주야간 좌표 프로필',
  '커스텀 일러스트 우선 사용', '로컬 PNG를 우선 사용하고 공식 캐시는 보존합니다 (새로고침 필요)',
  '커스텀 좌표 INI 사용', '[graph]만 읽고 [info]는 무시합니다 (새로고침 필요)',
  '일러스트 프로필 (수동)',
  '일반', '.hack.png 및 .config.ini 사용',
  '주간', '.day.hack.png 우선, 주간 INI가 일반 좌표를 덮어씀',
  '야간', '.night.hack.png 우선, 야간 INI가 일반 좌표를 덮어씀',
  '모드 파일 경로', '이미지 및 INI 폴더 표시',
  '이미지는 browser_cache/kcs2에 .hack.png / .day.hack.png / .night.hack.png로 저장하고 INI는 coord_mod에 저장합니다.',
  'INI 파일 수',
  'MOD ZIP 원클릭 가져오기',
  '일반 MOD 가져오기',
  '일반 MOD 캐시 ZIP을 선택합니다. .hack.png 및 .config.ini로 통일합니다.',
  '주간 MOD 가져오기',
  '예: 할로윈 주간 MOD. .day.hack.png 및 .day.config.ini로 통일합니다.',
  '야간 MOD 가져오기',
  '예: 잠옷 야간 MOD. .night.hack.png 및 .night.config.ini로 통일합니다.',
  'MOD ZIP 가져오는 중…',
  'MOD 가져오기 결과',
  '가져오기 완료: %1$s, 이미지 %2$d개, INI %3$d개, 기타 %4$d개 건너뜀. 게임을 새로고침하세요.',
  '가져오기 실패: %1$s'
 ]
}

# UI5 adds an actual persistent device-local day/night schedule.
KEYS.extend([
    'settings_mod_ggoto_day_start',
    'settings_mod_ggoto_night_start',
    'settings_mod_ggoto_profile_auto',
    'settings_mod_ggoto_profile_auto_summary',
    'settings_mod_ggoto_current_effective',
    'settings_mod_ggoto_time_duplicate',
])
EXTRA_TRANSLATIONS = {
    'values': [
        'Day begins', 'Night begins', 'Automatic (local clock)',
        'Use device time; change profile at port return',
        'Current effective mode: %1$s', 'Day and night start time cannot be the same.'
    ],
    'values-zh-rCN': [
        '日间开始时间', '夜间开始时间', '日夜自动切换',
        '按手机本地时间，在返回母港时切换',
        '当前使用：%1$s', '日间与夜间开始时间不能相同。'
    ],
    'values-zh-rTW': [
        '日間開始時間', '夜間開始時間', '日夜自動切換',
        '依手機本機時間，返回母港時切換',
        '目前使用：%1$s', '日間與夜間開始時間不可相同。'
    ],
    'values-ja': [
        '昼の開始時刻', '夜の開始時刻', '昼夜自動切替',
        '端末の現地時刻で、母港帰還時に切替',
        '現在のモード：%1$s', '昼と夜の開始時刻は同じにできません。'
    ],
    'values-ko': [
        '주간 시작 시각', '야간 시작 시각', '주야간 자동 전환',
        '휴대폰 현지 시간 기준으로 모항 귀환 시 전환',
        '현재 적용 모드: %1$s', '낮과 밤의 시작 시각은 같을 수 없습니다.'
    ],
}
for locale, extra in EXTRA_TRANSLATIONS.items():
    TRANSLATIONS[locale].extend(extra)


def patch(root):
    root = Path(root).resolve()
    constants = root / JAVA / 'Constants.java'
    activity = root / JAVA / 'Activity/BrowserActivity.kt'
    settings = root / JAVA / 'ui/component/SettingsBottomSheet.kt'
    originals = {}
    for path in (constants, activity, settings):
        if not path.is_file():
            raise PatchError('4.1 source file missing: ' + str(path))
        originals[path] = path.read_text(encoding='utf-8')

    c = replace_once(
        originals[constants],
        '    public static final String PREF_MOD_FPS = "pref_mod_fps";',
        '    public static final String PREF_MOD_FPS = "pref_mod_fps";\n'
        '    public static final String PREF_MOD_GGOTO_HACK = "pref_mod_ggoto_hack_png";\n'
        '    public static final String PREF_MOD_GGOTO_COORD = "pref_mod_ggoto_ini_coords";\n'
        '    public static final String PREF_MOD_GGOTO_PROFILE = "pref_mod_ggoto_profile";\n'
        '    public static final String PREF_MOD_GGOTO_DAY_START = "pref_mod_ggoto_day_start";\n'
        '    public static final String PREF_MOD_GGOTO_NIGHT_START = "pref_mod_ggoto_night_start";',
        'GGoto shared preference constants')

    a = replace_once(
        originals[activity],
        'import com.antest1.gotobrowser.Constants.PREF_MOD_FPS',
        'import com.antest1.gotobrowser.Constants.PREF_MOD_FPS\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_HACK\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_COORD\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_PROFILE\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_DAY_START\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_NIGHT_START\n'
        'import com.antest1.gotobrowser.Helpers.GGotoDayNightPolicy',
        'BrowserActivity GGoto imports')
    a = replace_once(
        a,
        '        PREF_MOD_CRIT,\n        PREF_MOD_KANTAI3D,',
        '        PREF_MOD_CRIT,\n'
        '        PREF_MOD_GGOTO_HACK,\n'
        '        PREF_MOD_GGOTO_COORD,\n'
        '        PREF_MOD_GGOTO_PROFILE,\n'
        '        PREF_MOD_GGOTO_DAY_START,\n'
        '        PREF_MOD_GGOTO_NIGHT_START,\n'
        '        PREF_MOD_KANTAI3D,',
        'BrowserActivity refresh settings')

    s = replace_once(
        originals[settings],
        'import com.antest1.gotobrowser.Constants.PREF_MOD_FPS',
        'import com.antest1.gotobrowser.Constants.PREF_MOD_FPS\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_HACK\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_COORD\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_PROFILE',
        'SettingsBottomSheet GGoto imports')

    a = replace_once(
        a,
        '    private fun onSettingChanged(key: String) {\n'
        '        when (key) {',
        '    private fun onSettingChanged(key: String) {\n'
        '        when (key) {\n'
        '            PREF_MOD_GGOTO_DAY_START, PREF_MOD_GGOTO_NIGHT_START -> {\n'
        '                GGotoDayNightPolicy.onSettingsChanged(applicationContext)\n'
        '            }',
        'BrowserActivity live timetable setting handling')

    s = replace_once(
        s,
        'import androidx.compose.runtime.Composable\n',
        'import androidx.activity.compose.rememberLauncherForActivityResult\n'
        'import androidx.activity.result.contract.ActivityResultContracts\n'
        'import androidx.compose.runtime.Composable\n',
        'SettingsBottomSheet document picker imports')
    s = replace_once(
        s,
        'import com.antest1.gotobrowser.Helpers.KcUtils\n',
        'import com.antest1.gotobrowser.Helpers.KcUtils\n'
        'import com.antest1.gotobrowser.Helpers.GGotoModImporter\n'
        'import com.antest1.gotobrowser.Helpers.GGotoDayNightPolicy\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_DAY_START\n'
        'import com.antest1.gotobrowser.Constants.PREF_MOD_GGOTO_NIGHT_START\n',
        'SettingsBottomSheet importer helper import')
    s = replace_once(
        s,
        'import kotlinx.coroutines.launch\n',
        'import kotlinx.coroutines.Dispatchers\n'
        'import kotlinx.coroutines.launch\n'
        'import kotlinx.coroutines.withContext\n',
        'SettingsBottomSheet IO coroutine imports')

    s = replace_once(
        s,
        '                ListItem(\n                    headlineContent = { Text(stringResource(R.string.settings_appinfo_label)) },',
        '''                // GGOTO UI4: direct entry for custom illustration settings.
                ListItem(
                    headlineContent = { Text(stringResource(R.string.settings_mod_ggoto_group)) },
                    supportingContent = { Text(stringResource(R.string.settings_mod_ggoto_main_hint)) },
                    modifier = Modifier.clickable { onScreenChanged(SettingsScreen.MODS) }
                )
                HorizontalDivider()
                ListItem(
                    headlineContent = { Text(stringResource(R.string.settings_appinfo_label)) },''',
        'Settings home GGoto entry')

    mod_anchor = '    // --- Group 1: General Mods -----------------------------------------------'
    mod_insert = '''    // --- GGoto custom illustration profiles ---------------------------------
    SectionHeader(R.string.settings_mod_ggoto_group)
    val ggotoProfileOptions = listOf(
        ListOption("auto", context.getString(R.string.settings_mod_ggoto_profile_auto),
            context.getString(R.string.settings_mod_ggoto_profile_auto_summary)),
        ListOption("normal", context.getString(R.string.settings_mod_ggoto_profile_normal),
            context.getString(R.string.settings_mod_ggoto_profile_normal_summary)),
        ListOption("day", context.getString(R.string.settings_mod_ggoto_profile_day),
            context.getString(R.string.settings_mod_ggoto_profile_day_summary)),
        ListOption("night", context.getString(R.string.settings_mod_ggoto_profile_night),
            context.getString(R.string.settings_mod_ggoto_profile_night_summary))
    )
    ListRow(
        viewModel = viewModel,
        key = PREF_MOD_GGOTO_PROFILE,
        titleRes = R.string.settings_mod_ggoto_profile,
        options = ggotoProfileOptions,
        defaultValue = "auto",
        onPersisted = { GGotoDayNightPolicy.onSettingsChanged(context) },
        onSettingChanged = onSettingChanged
    )
    var ggotoDayBegin by remember { mutableStateOf(viewModel?.getString(PREF_MOD_GGOTO_DAY_START, "08:00") ?: "08:00") }
    var ggotoNightBegin by remember { mutableStateOf(viewModel?.getString(PREF_MOD_GGOTO_NIGHT_START, "23:00") ?: "23:00") }
    var ggotoTimeWarning by remember { mutableStateOf(false) }
    ClickRow(
        title = R.string.settings_mod_ggoto_day_start,
        summaryText = ggotoDayBegin,
        onClick = {
            val minutes = GGotoDayNightPolicy.parseTime(ggotoDayBegin, 8 * 60)
            android.app.TimePickerDialog(context, { _, hour, minute ->
                val next = GGotoDayNightPolicy.formatTime(hour, minute)
                if (next == ggotoNightBegin) ggotoTimeWarning = true
                else {
                    ggotoTimeWarning = false
                    ggotoDayBegin = next
                    viewModel?.setString(PREF_MOD_GGOTO_DAY_START, next)
                    GGotoDayNightPolicy.onSettingsChanged(context)
                    onSettingChanged(PREF_MOD_GGOTO_DAY_START)
                }
            }, minutes / 60, minutes % 60, true).show()
        }
    )
    ClickRow(
        title = R.string.settings_mod_ggoto_night_start,
        summaryText = ggotoNightBegin,
        onClick = {
            val minutes = GGotoDayNightPolicy.parseTime(ggotoNightBegin, 23 * 60)
            android.app.TimePickerDialog(context, { _, hour, minute ->
                val next = GGotoDayNightPolicy.formatTime(hour, minute)
                if (next == ggotoDayBegin) ggotoTimeWarning = true
                else {
                    ggotoTimeWarning = false
                    ggotoNightBegin = next
                    viewModel?.setString(PREF_MOD_GGOTO_NIGHT_START, next)
                    GGotoDayNightPolicy.onSettingsChanged(context)
                    onSettingChanged(PREF_MOD_GGOTO_NIGHT_START)
                }
            }, minutes / 60, minutes % 60, true).show()
        }
    )
    if (ggotoTimeWarning) Text(
        stringResource(R.string.settings_mod_ggoto_time_duplicate),
        color = MaterialTheme.colorScheme.error,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
    val effectiveMode = GGotoDayNightPolicy.current(context)
    Text(
        text = stringResource(R.string.settings_mod_ggoto_current_effective,
            when(effectiveMode) {
                "night" -> context.getString(R.string.settings_mod_ggoto_profile_night)
                "day" -> context.getString(R.string.settings_mod_ggoto_profile_day)
                else -> context.getString(R.string.settings_mod_ggoto_profile_normal)
            }),
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
    )
    SwitchRow(viewModel, PREF_MOD_GGOTO_HACK,
        R.string.settings_mod_ggoto_hack, R.string.settings_mod_ggoto_hack_summary,
        defaultValue = true, onSettingChanged = onSettingChanged)
    SwitchRow(viewModel, PREF_MOD_GGOTO_COORD,
        R.string.settings_mod_ggoto_coord, R.string.settings_mod_ggoto_coord_summary,
        defaultValue = true, onSettingChanged = onSettingChanged)

    // --- One-click ZIP import: the selected button defines the target profile.
    SectionHeader(R.string.settings_mod_ggoto_import_group)
    var pendingImportProfile by remember { mutableStateOf("normal") }
    var importBusy by remember { mutableStateOf(false) }
    var importResultMessage by remember { mutableStateOf<String?>(null) }
    val importScope = rememberCoroutineScope()
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && !isPreview) {
            val selectedProfile = pendingImportProfile
            importBusy = true
            importScope.launch {
                val result = withContext(Dispatchers.IO) {
                    GGotoModImporter.importZip(context, uri, selectedProfile)
                }
                importBusy = false
                if (result.isSuccess) {
                    // Import never changes the currently selected auto/manual policy.
                    // It only stores files in the requested profile's namespace.
                    viewModel?.setBoolean(PREF_MOD_GGOTO_HACK, true)
                    viewModel?.setBoolean(PREF_MOD_GGOTO_COORD, true)
                    val profileLabel = when (selectedProfile) {
                        "day" -> context.getString(R.string.settings_mod_ggoto_profile_day)
                        "night" -> context.getString(R.string.settings_mod_ggoto_profile_night)
                        else -> context.getString(R.string.settings_mod_ggoto_profile_normal)
                    }
                    importResultMessage = context.getString(
                        R.string.settings_mod_ggoto_import_success,
                        profileLabel, result.imageCount, result.iniCount, result.ignoredCount
                    )
                } else {
                    importResultMessage = context.getString(
                        R.string.settings_mod_ggoto_import_failed,
                        result.error ?: "Unknown error"
                    )
                }
            }
        }
    }
    fun launchGgotoImport(profile: String) {
        pendingImportProfile = profile
        importLauncher.launch(arrayOf("*/*"))
    }
    ClickRow(
        title = R.string.settings_mod_ggoto_import_normal,
        summaryText = context.getString(R.string.settings_mod_ggoto_import_normal_summary),
        enabled = !isPreview && !importBusy,
        onClick = { launchGgotoImport("normal") }
    )
    ClickRow(
        title = R.string.settings_mod_ggoto_import_day,
        summaryText = context.getString(R.string.settings_mod_ggoto_import_day_summary),
        enabled = !isPreview && !importBusy,
        onClick = { launchGgotoImport("day") }
    )
    ClickRow(
        title = R.string.settings_mod_ggoto_import_night,
        summaryText = context.getString(R.string.settings_mod_ggoto_import_night_summary),
        enabled = !isPreview && !importBusy,
        onClick = { launchGgotoImport("night") }
    )
    if (importBusy) {
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        Text(
            text = stringResource(R.string.settings_mod_ggoto_import_busy),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodySmall
        )
    }
    importResultMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { importResultMessage = null },
            title = { Text(stringResource(R.string.settings_mod_ggoto_import_result)) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { importResultMessage = null }) {
                    Text(stringResource(R.string.action_ok))
                }
            }
        )
    }

    var showGgotoPaths by remember { mutableStateOf(false) }
    ClickRow(
        title = R.string.settings_mod_ggoto_paths,
        summary = R.string.settings_mod_ggoto_paths_summary,
        onClick = { showGgotoPaths = true }
    )
    if (showGgotoPaths) {
        val root = context.getExternalFilesDir(null)?.absolutePath ?: "(unavailable)"
        val coordDir = java.io.File(root, "coord_mod")
        val iniCount = coordDir.listFiles()?.count {
            it.isFile && it.name.endsWith(".config.ini", ignoreCase = true)
        } ?: 0
        AlertDialog(
            onDismissRequest = { showGgotoPaths = false },
            title = { Text(stringResource(R.string.settings_mod_ggoto_paths)) },
            text = {
                Text(
                    root + "/coord_mod/\\n" +
                    stringResource(R.string.settings_mod_ggoto_count) + ": " + iniCount +
                    "\\n\\n" + root + "/browser_cache/kcs2/\\n" +
                    stringResource(R.string.settings_mod_ggoto_paths_note)
                )
            },
            confirmButton = {
                TextButton(onClick = { showGgotoPaths = false }) {
                    Text(stringResource(R.string.action_ok))
                }
            }
        )
    }

    // --- Group 1: General Mods -----------------------------------------------'''
    s = replace_once(s, mod_anchor, mod_insert, 'ModsSection GGoto profile selector')

    locale_snippets = {}
    for directory, texts in TRANSLATIONS.items():
        if len(texts) != len(KEYS):
            raise PatchError(f'Translation length mismatch for {directory}: {len(texts)} != {len(KEYS)}')
        locale = root / 'app/src/main/res' / directory / 'strings.xml'
        if not locale.is_file():
            raise PatchError('4.1 locale missing: ' + str(locale))
        original = locale.read_text(encoding='utf-8')
        if any(('name="' + key + '"') in original for key in KEYS):
            raise PatchError('GGoto UI strings already exist in ' + str(locale) + '; use clean official 4.1 source')
        snippet = ''.join(
            '    <string name="' + key + '">' + escape(value, quote=False) + '</string>\n'
            for key, value in zip(KEYS, texts)
        )
        locale_snippets[locale] = snippet

    # Apply the lower-level 4.1 resource + coordinate patch only after all UI anchors pass.
    patch_core(root)
    gradle = root / 'app/build.gradle'
    gradle_text = gradle.read_text(encoding='utf-8')
    gradle.write_text(replace_once(gradle_text, '        versionName "4.1"',
                                   '        versionName "4.1-GGOTO-UI5"', 'GGoto UI5 version name'),
                      encoding='utf-8')

    for path, content in ((constants, c), (activity, a), (settings, s)):
        path.write_text(content, encoding='utf-8')
    # Core patch changes the launcher app_name in all locale files. Append GGoto
    # labels to that post-core content so the custom app name is not overwritten.
    for locale, snippet in locale_snippets.items():
        current = locale.read_text(encoding='utf-8')
        locale.write_text(replace_once(current, '</resources>', snippet + '</resources>',
                                       'append GGoto strings ' + str(locale)), encoding='utf-8')

    # Post-patch invariants: selector is present and refresh-bound; helper reads same preference.
    if 'PREF_MOD_GGOTO_PROFILE' not in a or 'PREF_MOD_GGOTO_PROFILE' not in s:
        raise PatchError('Profile preference was not wired to UI and refresh')
    loader = (root / JAVA / 'Helpers/GGotoHackLoader.java').read_text(encoding='utf-8')
    helper = (root / JAVA / 'Helpers/ShipGraphOverride.java').read_text(encoding='utf-8')
    importer = root / JAVA / 'Helpers/GGotoModImporter.java'
    if not importer.is_file():
        raise PatchError('GGotoModImporter.java was not installed')
    policy = (root / JAVA / 'Helpers/GGotoDayNightPolicy.java').read_text(encoding='utf-8')
    if 'GGotoDayNightPolicy.current(context)' not in loader or 'GGotoDayNightPolicy.current(context)' not in helper:
        raise PatchError('Image and coordinate modules are not wired to the day/night policy')
    if 'PREF_MOD_GGOTO_PROFILE' not in policy:
        raise PatchError('Auto/manual policy preference is missing')

    if 'settings_mod_ggoto_import_day' not in s or 'GGotoModImporter.importZip' not in s:
        raise PatchError('One-click import UI was not wired')
    if 'settings_mod_ggoto_import_night' not in s or 'settings_mod_ggoto_import_normal' not in s:
        raise PatchError('Normal/day/night import actions are incomplete')
    print('GGOTO 4.1 UI5 PATCH OK')
    print(' - settings home entry + manual Normal/Day/Night profile selector')
    print(' - profile selection is included in BrowserActivity refresh settings')
    print(' - normal/day/night image overlays and matching INI profiles wired')
    print(' - missing day/night assets keep official visuals and coordinates')
    print(' - two independent switches retained: image override and coordinate override')
    print(' - INI parser reads only [graph], ignores [info]')
    print(' - local-clock auto mode with editable day/night start and manual override')
    print(' - transitions at port return; import keeps current auto/manual mode')
    print(' - one-click normal/day/night ZIP import via Android document picker')
    print(' - archive wrapper folders and repeated cache/cache prefixes normalized')
    print(' - pajamas legacy suffixes normalized to .night.hack.png / .night.config.ini')
    print(' - Halloween legacy suffixes normalized to .day.hack.png / .day.config.ini')
    print(' - JSON sidecars skipped; PNG and [graph] INI validated before import')

if __name__ == '__main__':
    try:
        if len(sys.argv) != 2:
            raise PatchError('Usage: python3 patch_source41_daynight.py /path/to/GotoBrowser-4.1')
        patch(Path(sys.argv[1]))
    except (OSError, PatchError) as exc:
        print('GGOTO 4.1 UI5 PATCH ERROR: ' + str(exc), file=sys.stderr)
        sys.exit(2)
